<?php 

class Billing extends Admin_Controller{

	public function __construct(){
		parent::__construct();
        $this->data['page_title'] = 'Billing Management';
		$this->data['c'] = '';
		$this->data['m'] = '';
		$this->data['page_desc'] = 'Bookings';
		$this->load->model('reservation_m');
	
		
	}

	public function index(){
	
		$this->data['reservations'] = $this->reservation_m->getReservations();	
        $this->data['status'] = 	$this->status_m->getReservationStatus();  
        $this->data['payment'] =  $this->payment_m->get();  
		$this->data['subview'] = 'billing_management/index';
		$this->load->view('layouts/_layout_main',$this->data);
	}
   public function current(){
        
        $this->data['reservations'] = $this->reservation_m->getCurrentReservations();  
        $this->data['status'] =     $this->status_m->getReservationStatus();  
        $this->data['payment'] =  $this->payment_m->get();  
        $this->data['subview'] = 'booking/index';
        $this->load->view('layouts/_layout_main',$this->data);
    }
    public function future(){
        
        $this->data['reservations'] = $this->reservation_m->getFutureReservations();  
        $this->data['status'] =     $this->status_m->getReservationStatus();  
        $this->data['payment'] =  $this->payment_m->get();  
        $this->data['subview'] = 'booking/future';
        $this->load->view('layouts/_layout_main',$this->data);
    }
    public function ajax_add()
    {
      $res_id = $this->reservation_m->getReservationByRefNo($this->input->post('id'));
      $reservation= $this->reservation_m->getReservation($res_id);
      $amount =  $this->input->post('amount');

     
        $data = array(
                'reservation_id' =>$res_id,
                'date_paid' => $this->input->post('date_paid'),
                 'amount' => $amount,
                  'mode_of_payment' => $this->input->post('mode_of_payment'),
               
            );
       
        $insert = $this->db->insert('payment_history',$data);
        $reservation_payment_status_id = 2;
        if($amount>=($reservation->cost+$reservation->addon_cost)){
                $reservation_payment_status_id = 1;

        }

          $data2 = array(
            'balance' => ($reservation->cost+$reservation->addon_cost) - $amount,
             'reservation_payment_status_id' =>  $reservation_payment_status_id,
            );

        $this->db->update('reservation_payment', $data2, array('reservation_id' => $res_id));  
        echo json_encode(array("status" => TRUE));
    }

    
  
   
    public function deactivate()
    {
       
         $data = array(
               
                'active' => 0,
               
            );
        $this->db->update('addons', $data, array('addon_id' => $this->input->post('addon_id')));
        redirect('addon');
      
    }
   public function activate()
    {
       
         $data = array(
               
                'active' => 1,
               
            );
        $this->db->update('addons', $data, array('addon_id' => $this->input->post('addon_id')));
       redirect('addon');
    }
    public function ajax_delete($id)
    {
        $this->package_m->delete($id);
        echo json_encode(array("status" => TRUE));
    }
	
	

    



}