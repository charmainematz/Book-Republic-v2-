<?php 

class Event_type extends Admin_Controller{

	public function __construct(){
		parent::__construct();
		$this->data['page_title'] = 'Event Type';
		$this->data['c'] = 'event_type';
		$this->data['m'] = '';
		$this->data['page_desc'] = 'List of Event Types';
		$this->load->model('event_type_m');
		
		
	}

	public function index(){
		
		$this->data['event_types'] = $this->event_type_m->get();		
		$this->data['subview'] = 'event_type/index';
		$this->load->view('layouts/_layout_main',$this->data);
	}


	public function ajax_add()
    {
        $this->_validate('create');
        $data = array(
                'event_type_name' => $this->input->post('event_type_name'),
                'event_type_desc' => $this->input->post('event_type_desc'),
               
            );
        $data['created_by'] = $this->session->userdata('user_id');
        $data['date_created'] = date('Y-m-d');
        $insert = $this->db->insert('event_types',$data);
        echo json_encode(array("status" => TRUE));
    }

    public function ajax_edit($id)
    {
        $data = $this->event_type_m->get($id);
        //$data->dob = ($data->dob == '0000-00-00') ? '' : $data->dob; // if 0000-00-00 set tu empty for datepicker compatibility
        echo json_encode($data);
    }

    public function ajax_update()
    {
        $this->_validate('update');
        $data = array(
                'event_type_name' => $this->input->post('event_type_name'),
                'event_type_desc' => $this->input->post('event_type_desc'),
               
            );
        $this->event_type_m->save($data,$this->input->post('id'));
        echo json_encode(array("status" => TRUE));
    }
 
    public function ajax_delete($id)
    {
        $this->event_type_m->delete($id);
        echo json_encode(array("status" => TRUE));
    }
	
	 private function _validate($method)
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
 
      
        if($this->input->post('event_type_name') == '')
        {
            $data['inputerror'][] = 'event_type_name';
            $data['error_string'][] = 'Event Type Name is required';
            $data['status'] = FALSE;
        }else{
            if ($method == 'create') {
                $this->db->where('event_type_name',$this->input->post('event_type_name'));
                $x = count($this->event_type_m->get());
                if($x >= 1){
                    $data['inputerror'][] = 'event_type_name';
                    $data['error_string'][] = 'Event Type Name  already Exists';
                    $data['status'] = FALSE;
                }
            }
        }

         if($this->input->post('event_type_desc') == '')
        {
            $data['inputerror'][] = 'event_type_desc';
            $data['error_string'][] = 'Description is required';
            $data['status'] = FALSE;
        }
 
        
 
        if($data['status'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }



}