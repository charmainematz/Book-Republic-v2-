<?php 

class Booking extends Admin_Controller{

	public function __construct(){
		parent::__construct();
        $this->data['page_title'] = ' Booking';
		$this->data['c'] = 'List of Bookings';
		$this->data['m'] = '';
		$this->data['page_desc'] = 'Bookings';
		$this->load->model('reservation_m');
	
		
	}

	public function index(){
		
		$this->data['reservations'] = $this->reservation_m->getReservations();	
        $this->data['status'] = 	$this->status_m->getReservationStatus();  
        $this->data['payment'] =  $this->payment_m->get();  
		$this->data['subview'] = 'booking/index';
		$this->load->view('layouts/_layout_main',$this->data);
	}
   public function current(){
        
        $this->data['reservations'] = $this->reservation_m->getCurrentReservations();  
        $this->data['status'] =     $this->status_m->getReservationStatus();  
        $this->data['payment'] =  $this->payment_m->get();  
        $this->data['subview'] = 'booking/index';
        $this->load->view('layouts/_layout_main',$this->data);
    }
    public function future(){
        
        $this->data['reservations'] = $this->reservation_m->getFutureReservations();  
        $this->data['status'] =     $this->status_m->getReservationStatus();  
        $this->data['payment'] =  $this->payment_m->get();  
        $this->data['subview'] = 'booking/future';
        $this->load->view('layouts/_layout_main',$this->data);
    }
    public function view($res_id){
          $data3 = array(
            'notif' =>0,
      );

          print_r($res_id);

        $this->data['m']= 'View Booking';
        $this->db->update('reservation', $data3, array('reservation_id' => $res_id));  
      
        $this->data['reservation']= $this->reservation_m->getReservation($res_id);
        $this->data['payment_history']= $this->payment_history_m->getPaymentHistory($res_id);
        $this->data['addons']= $this->addon_availed_m-> getPackageAvailed($res_id);

        $this->data['subview'] = 'booking/view';
        $this->load->view('layouts/_layout_main',$this->data);

  
    }
   
    public function deactivate()
    {
       
         $data = array(
               
                'active' => 0,
               
            );
        $this->db->update('addons', $data, array('addon_id' => $this->input->post('addon_id')));
        redirect('addon');
      
    }
   public function activate()
    {
       
         $data = array(
               
                'active' => 1,
               
            );
        $this->db->update('addons', $data, array('addon_id' => $this->input->post('addon_id')));
       redirect('addon');
    }
    public function ajax_delete($id)
    {
        $this->package_m->delete($id);
        echo json_encode(array("status" => TRUE));
    }
	
	

    



}