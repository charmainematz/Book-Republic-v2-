<?php 

class Addon extends Admin_Controller{

	public function __construct(){
		parent::__construct();
		$this->data['page_title'] = 'Addon';
		$this->data['c'] = 'Package';
		$this->data['m'] = '';
		$this->data['page_desc'] = 'Addon Packages';
		$this->load->model('addon_m');
	
		
	}

    public function profit_report($year){
       
      
      $months = array('01','02','03','04','05','06','07','08','09','10','11','12',);
      $addons= array();
      $addon =array();
      $addonss = $this->addon_m->get();



      foreach($addonss as $add){

                array_push($addon, $add->addon_name);
            foreach($months as $m){
                 $addon_profit= $this->addon_availed_m->getMonthlyProfit($m,$year,$add->addon_id);
              
                array_push($addon,$addon_profit);



            }

            array_push($addons,$addon);
            $addon = array();
      }

      
   
        echo json_encode($addons,true);

  }


	public function index(){
		
		$this->data['addons'] = $this->addon_m->get();	
       	
		$this->data['subview'] = 'addon/index';
		$this->load->view('layouts/_layout_main',$this->data);
	}
    public function avail_package($service_id, $reservation_id){

        $reservation= $this->reservation_m->get($reservation_id);
        $this->data['reservation'] = $reservation;

        $this->data['event'] = $this->event_m->get($reservation->event_id);
        $this->data['packages'] = $this->addon_m->getPackages($service_id);
        $this->data['event'] = $this->event_m->get($reservation->event_id);
        $this->data['service'] = $this->service_m->get($service_id);
        $this->data['package_availed_by_type'] = $this->addon_availed_m->getPackageAvailedByCategory($service_id, $reservation_id);
        $this->data['subview'] = 'event/avail_service';
        $this->load->view('layouts/_layout_main',$this->data);

    }

    public function updateAddonsCost($reservation_id){
        $cost = $this->addon_availed_m->updateAddonsCost($reservation_id);

        $data = array(
                
                'addon_cost' => $cost,
               
            );
         $this->db->update('reservation', $data, array('reservation_id' => $reservation_id));

    }
    public function add_addon(){

        
         $data = array(
                'reservation_id' => $this->input->post("reservation_id"),
                'add_on_id' =>$this->input->post("add_on_id"),
               
            );
       
        $data['date_created'] = date('Y-m-d');
        $insert = $this->db->insert('addon_availed',$data);

        $this->updateAddonsCost($this->input->post("reservation_id"));

         $_SESSION["res_id"]=$this->input->post("reservation_id");



        redirect('room/findBooking');
    }
     public function updateQuantity(){

        $service_id =$this->input->post('service_id');
        $reservation_id =$this->input->post('reservation_id');
        
          $data = array(
                
                'quantity' => $this->input->post('quantity'),
               
            );
         $this->db->update('services_availed2', $data, array('availed_package_id' =>   $this->input->post('availed_package_id')));

          redirect('service/avail_package/'.$service_id.'/'.$reservation_id);
    }
     public function remove_addon(){
       
           
        $this->addon_availed_m->remove_availedPackage($this->input->post("reservation_id"), $this->input->post("add_on_id"));
          $this->updateAddonsCost($this->input->post("reservation_id"));

            $_SESSION["res_id"]=$this->input->post("reservation_id");

        redirect('room/findBooking');
    }

	public function ajax_add()
    {
        
        $data = array(
                'addon_name' => $this->input->post('addon_name'),
                'addon_desc' => $this->input->post('addon_desc'),
                'cost' => $this->input->post('cost'),
               
            );
        $data['created_by'] = $this->session->userdata('user_id');
        $data['date_created'] = date('Y-m-d');
        $insert = $this->db->insert('addons',$data);
        echo json_encode(array("status" => TRUE));
    }
    public function ajax_edit($id)
    {
     
      
        $data = $this->addon_m->get($id);
        //$data->dob = ($data->dob == '0000-00-00') ? '' : $data->dob; // if 0000-00-00 set tu empty for datepicker compatibility
        echo json_encode($data);
    }
    
    public function ajax_update()
    {
      
        $data = array(
               'addon_name' => $this->input->post('addon_name'),
                 'addon_desc' => $this->input->post('addon_desc'),
                'cost' => $this->input->post('cost'),
                
            );

         $this->db->update('addons', $data, array('addon_id' => $this->input->post('id')));
      
        echo json_encode(array("status" => TRUE));
      
       
    }
    public function deactivate()
    {
       
         $data = array(
               
                'active' => 0,
               
            );
        $this->db->update('addons', $data, array('addon_id' => $this->input->post('addon_id')));
        redirect('addon');
      
    }
   public function activate()
    {
       
         $data = array(
               
                'active' => 1,
               
            );
        $this->db->update('addons', $data, array('addon_id' => $this->input->post('addon_id')));
       redirect('addon');
    }
    public function ajax_delete($id)
    {
        $this->addon_m->delete($id);
        echo json_encode(array("status" => TRUE));
    }
	
	

    



}