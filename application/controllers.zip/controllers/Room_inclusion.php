<?php 

class Room_inclusion extends Admin_Controller{

	public function __construct(){
		parent::__construct();
		$this->data['page_title'] = 'Room Inclusion';
		$this->data['c'] = 'room_type';
		$this->data['m'] = '';
		$this->data['page_desc'] = 'Control Panel';
		$this->load->model('room_inclusion_m');
		
		
	}

    public function delete($id)
    {
        $this->room_inclusion_m->delete($id);
        redirect('settings');
    }
	



}