<?php 

class Guest extends Admin_Controller{

	public function __construct(){
		parent::__construct();
		$this->data['page_title'] = 'My Booking';
		$this->data['c'] = 'client';
		$this->data['m'] = '';
		$this->data['page_desc'] = 'List of Clients';
         $this->load->model('client_m');
		
	}

	public function index(){
		
		$this->data['subview'] = 'guest/mybooking';
		$this->load->view('layouts/_layout_guest',$this->data);
	}

	public function inquire(){
	
		$data = array(
            'name' => $this->input->post('name'),
            'phone' =>$this->input->post('phone'),
            'email' =>$this->input->post('email'),
            'message' =>$this->input->post('message'),
                        
        );
 
	        $data['date_created'] = date('Y-m-d');
	        $insert = $this->db->insert('inquiries',$data);

	     
	         redirect("auth/home", 'refresh');

	}
	

}