<?php 

class Journal extends Admin_Controller{

	public function __construct(){
		parent::__construct();
		$this->data['page_title'] = 'Journal';
		$this->data['c'] = 'Journal';
		$this->data['m'] = 'Journal';
		$this->data['page_desc'] = 'List of Journal Entries';
		$this->load->model('journal_m');
        $this->load->model('employee_m');
        $this->load->model('ion_auth_model');
        $this->load->library('pagination');
	}

	public function index(){
	

        //$config = array();
      //  $config["base_url"] = base_url() . "journal/index";
       // $config["total_rows"] = count($this->journal_m->get());
      //  $config["per_page"] = 10;
       // $config["uri_segment"] = 3;

      ///  $this->pagination->initialize($config);

      //  $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
      //  $data["results"] = $this->Countries->
       //     fetch_countries($config["per_page"], $page);
      //  $data["links"] = $this->pagination->create_links();

		$this->data['entries'] = $this->journal_m->get();
	    $this->data['employees'] = $this->employee_m->get();
		$this->data['subview'] = 'journal/index';
		$this->load->view('layouts/_layout_main',$this->data);
	}
    public function ajax_read($id)
    {
        $data = $this->journal_m->get($id);
        echo json_encode($data);
    }
    public function write(){
   
        $this->data['page_desc'] = 'Write Entry';
        $this->data['c'] = 'Journal';
        $this->data['m'] = 'Write Entry';
        $this->data['subview'] = 'journal/write';
        $this->load->view('layouts/_layout_main',$this->data);
        if($this->input->post('publish')){


        }
        if($this->input->post('submit')=='save_draft'){
            $data = array(
                'entry_content' => $this->input->post('entry'),
                'title' => $this->input->post('title'),
                'status' => 'draft',
               'user_id' => $this->session->userdata('user_id'),
               'date_created' =>  date('Y-m-d H:i:s'),
            );

            $this->db->insert('journals',$data);
            redirect('journal');
        }


    }
	public function save(){
        
        $this->_validate('create');
        $data = array(
                'entry' => $this->input->post('entry'),
                'title' => $this->input->post('title'),
                'status' => 'draft',
               
            );
    }
    public function edit($id){
        
        $this->_validate('create');
        $data = array(
                'entry' => $this->input->post('entry'),
                'title' => $this->input->post('title'),
                'status' => 'draft',
               
            );
    }
	

    public function ajax_edit($id)
    {
        $data = $this->employee_m->employee_list($id);
        //$data->dob = ($data->dob == '0000-00-00') ? '' : $data->dob; // if 0000-00-00 set tu empty for datepicker compatibility
        echo json_encode($data);
    }

    public function ajax_update()
    {
        $this->_validate('update');
        $data = array(
                'employee_number' => $this->input->post('employee_number'),
                'lastname' => $this->input->post('lastname'),
                'firstname' => $this->input->post('firstname'),
                'middlename' => $this->input->post('middlename'),
                'birthdate' => $this->input->post('birthdate'),
                'position_id' => $this->input->post('position_id'),
                'personnel_type_id' => $this->input->post('personnel_type_id'),
                'address' => $this->input->post('address'),
                'contact' => $this->input->post('contact'),

               
            );
       	if($this->input->post('remove_photo')) // if remove photo checked
        {
            if(file_exists('upload/'.$this->input->post('remove_photo')) && $this->input->post('remove_photo'))
                unlink('upload/'.$this->input->post('remove_photo'));
            $data['photo'] = '';
        }
 
        if(!empty($_FILES['photo']['name']))
        {
            $upload = $this->_do_upload();
             
            //delete file
            $employee = $this->employee_m->get($this->input->post('id'));
            if(file_exists('upload/'.$employee->photo) && $employee->photo)
                unlink('upload/'.$employee->photo);
 
            $data['photo'] = $upload;
        }

        $this->employee_m->save($data,$this->input->post('id'));
        echo json_encode(array("status" => TRUE));
    }
 
    public function ajax_delete($id)
    {
        $this->employee_m->delete($id);
        echo json_encode(array("status" => TRUE));
    }
	
	 private function _validate($method)
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
 
      

        if($this->input->post('lastname') == '')
        {
            $data['inputerror'][] = 'lastname';
            $data['error_string'][] = 'Lastname is required';
            $data['status'] = FALSE;
        }
      
        
 
        if($data['status'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }

    private function _do_upload()
    {
        $config['upload_path']          = 'upload/';
        $config['allowed_types']        = 'gif|jpg|png';
        $config['max_size']             = 10000; //set max size allowed in Kilobyte
        $config['max_width']            = 1000; // set max width image allowed
        $config['max_height']           = 1000; // set max height allowed
        $config['file_name']            = round(microtime(true) * 1000); //just milisecond timestamp fot unique name
 
        $this->load->library('upload', $config);
 
        if(!$this->upload->do_upload('photo')) //upload and validate
        {
            $data['inputerror'][] = 'photo';
            $data['error_string'][] = 'Upload error: '.$this->upload->display_errors('',''); //show ajax error
            $data['status'] = FALSE;
            echo json_encode($data);
            exit();
        }
        return $this->upload->data('file_name');
    }


	public function _unique_employee_name ($str)
	{
		// Do NOT validate if Division Name already exists
		// UNLESS it's the Divisio Name for the current Division
		
		$id = $this->uri->segment(3);
		$this->db->where('employee_name', $this->input->post('employee_name'));
		!$id || $this->db->where('employee_id !=', $id);
		$employee = $this->employee_m->get();
		
		if (count($employee)) {
			$this->form_validation->set_message('_unique_employee_name', '%s Already Exists ');
			//echo $id;
			return FALSE;

		}
		
		return TRUE;
	}

	
	public function deactivate($id){
		$update['active'] = 0;
		$this->db->where('employee_id',$id);
		$this->db->update('p4s_employees',$update);
		$this->session->set_flashdata('edit','Record Deactivated');
		redirect('employee');
	}

	public function activate($id){
		$update['active'] = 1;
		$this->db->where('employee_id',$id);
		$this->db->update('p4s_employees',$update);
		$this->session->set_flashdata('edit','Record Activated');
		redirect('employee');
	}

}