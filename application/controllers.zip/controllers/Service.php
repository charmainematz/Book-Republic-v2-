<?php 

class Service extends Admin_Controller{

	public function __construct(){
		parent::__construct();
		$this->data['page_title'] = 'Service';
		$this->data['c'] = 'service';
		$this->data['m'] = '';
		$this->data['page_desc'] = 'List of Services Offered';
		$this->load->model('service_m');
		$this->load->model('package_m');
        $this->load->model('reservation_m');
        $this->load->model('event_m');
		$this->load->model('services_availed_m');
	}

	public function index(){
		
		$this->data['services'] = $this->service_m->get();		
		$this->data['subview'] = 'service/index';
		$this->load->view('layouts/_layout_main',$this->data);
	}
    public function avail_package($service_id, $reservation_id){

        $reservation= $this->reservation_m->get($reservation_id);
        $this->data['reservation'] = $reservation;

        $this->data['event'] = $this->event_m->get($reservation->event_id);
        $this->data['packages'] = $this->package_m->getPackages($service_id);
        $this->data['event'] = $this->event_m->get($reservation->event_id);
        $this->data['service'] = $this->service_m->get($service_id);
        $this->data['package_availed_by_type'] = $this->services_availed_m->getPackageAvailedByCategory($service_id, $reservation_id);
        $this->data['subview'] = 'event/avail_service';
        $this->load->view('layouts/_layout_main',$this->data);

    }
    public function addPackage($reservation_id, $package_id){

         $service_id = $this->package_m->get($package_id)->service_id;
         $data = array(
                'reservation_id' => $reservation_id,
                'package_id' => $package_id,
               
            );
        $data['created_by'] = $this->session->userdata('user_id');
        $data['date_created'] = date('Y-m-d');
        $insert = $this->db->insert('services_availed2',$data);

        redirect('service/avail_package/'.$service_id.'/'.$reservation_id);
    }
     public function updateQuantity(){

        $service_id =$this->input->post('service_id');
        $reservation_id =$this->input->post('reservation_id');
        
          $data = array(
                
                'quantity' => $this->input->post('quantity'),
               
            );
         $this->db->update('services_availed2', $data, array('availed_package_id' =>   $this->input->post('availed_package_id')));

          redirect('service/avail_package/'.$service_id.'/'.$reservation_id);
    }
     public function remove_availedPackage($reservation_id, $package_id){
       $service_id = $this->package_m->get($package_id)->service_id;
           
        $this->services_availed_m->remove_availedPackage($reservation_id, $package_id);
        

        redirect('service/avail_package/'.$service_id.'/'.$reservation_id);
    }
    
	public function ajax_add()
    {
        $this->_validate('create');
        $data = array(
                'service_name' => $this->input->post('service_name'),
                'service_desc' => $this->input->post('service_desc'),
               
            );
        $data['created_by'] = $this->session->userdata('user_id');
        $data['date_created'] = date('Y-m-d');
        $insert = $this->db->insert('services',$data);
        echo json_encode(array("status" => TRUE));
    }

    public function ajax_edit($id)
    {
        $data = $this->service_m->get($id);
        //$data->dob = ($data->dob == '0000-00-00') ? '' : $data->dob; // if 0000-00-00 set tu empty for datepicker compatibility
        echo json_encode($data);
    }

    public function ajax_update()
    {
        $this->_validate('update');
        $data = array(
                'service_name' => $this->input->post('service_name'),
                'service_desc' => $this->input->post('service_desc'),
               
            );
        $this->service_m->save($data,$this->input->post('id'));
        echo json_encode(array("status" => TRUE));
    }
 
    public function ajax_delete($id)
    {
        $this->service_m->delete($id);
        echo json_encode(array("status" => TRUE));
    }
	
	 private function _validate($method)
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['status'] = TRUE;
 
      
        if($this->input->post('service_name') == '')
        {
            $data['inputerror'][] = 'service_name';
            $data['error_string'][] = 'Service Name is required';
            $data['status'] = FALSE;
        }else{
            if ($method == 'create') {
                $this->db->where('service_name',$this->input->post('service_name'));
                $x = count($this->service_m->get());
                if($x >= 1){
                    $data['inputerror'][] = 'service_name';
                    $data['error_string'][] = 'Service Name  already Exists';
                    $data['status'] = FALSE;
                }
            }
        }

         if($this->input->post('service_desc') == '')
        {
            $data['inputerror'][] = 'service_desc';
            $data['error_string'][] = 'Description is required';
            $data['status'] = FALSE;
        }
 
        
 
        if($data['status'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }



}