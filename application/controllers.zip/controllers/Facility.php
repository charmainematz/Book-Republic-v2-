<?php 

class Facility extends Admin_Controller{

	public function __construct(){
		parent::__construct();
		$this->data['page_title'] = 'Facility';
		$this->data['c'] = 'facility';
		$this->data['m'] = '';
		$this->data['page_desc'] = 'Control Panel';
		$this->load->model('facility_m');
		
		
	}

	public function index(){
		
		$this->data['facilities'] = $this->facility_m->get();		
		$this->data['subview'] = 'facility/index';
		$this->load->view('layouts/_layout_main',$this->data);
	}


	public function ajax_add()
    {
        $this->_validate('create');
        $data = array(
                'facility_name' => $this->input->post('facility_name'),
                'facility_desc' => $this->input->post('facility_desc'),
               
            );
        $data['created_by'] = $this->session->userdata('user_id');
        $data['date_created'] = date('Y-m-d');
        $insert = $this->db->insert('facilities',$data);
        echo json_encode(array("status" => TRUE));
    }

    public function ajax_edit($id)
    {
        $data = $this->facility_m->get($id);
      
        echo json_encode($data);
    }

    public function ajax_update()
    {
        $this->_validate('update');
        $data = array(
                'facility_name' => $this->input->post('facility_name'),
                'facility_desc' => $this->input->post('facility_desc'),
               
            );
        $this->db->update('facilities', $data, array('facility_id' => $this->input->post('id')));
      
        echo json_encode(array("status" => TRUE));
    }
 
    public function ajax_delete($id)
    {
        $this->facility_m->delete($id);
        echo json_encode(array("facility" => TRUE));
    }
	public function deactivate()
    {
       
         $data = array(
               
                'active' => 0,
               
            );
        $this->db->update('facilities', $data, array('facility_id' => $this->input->post('facility_id')));
        redirect('facility');
      
    }
   public function activate()
    {
       
         $data = array(
               
                'active' => 1,
               
            );
        $this->db->update('facilities', $data, array('facility_id' => $this->input->post('facility_id')));
       redirect('facility');
    }
	 private function _validate($method)
    
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['facility'] = TRUE;
 
      
        if($this->input->post('facility_name') == '')
        {
            $data['inputerror'][] = 'facility_name';
            $data['error_string'][] = 'facility Name is required';
            $data['facility'] = FALSE;
        }else{
            if ($method == 'create') {
                $this->db->where('facility_name',$this->input->post('facility_name'));
                $x = count($this->facility_m->get());
                if($x >= 1){
                    $data['inputerror'][] = 'facility_name';
                    $data['error_string'][] = 'facility Name  already Exists';
                    $data['facility'] = FALSE;
                }
            }
        }

         if($this->input->post('facility_desc') == '')
        {
            $data['inputerror'][] = 'facility_desc';
            $data['error_string'][] = 'Description is required';
            $data['facility'] = FALSE;
        }
 
        
 
        if($data['facility'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }



}