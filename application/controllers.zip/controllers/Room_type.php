<?php 

class Room_type extends Admin_Controller{

	public function __construct(){
		parent::__construct();
		$this->data['page_title'] = 'Room Type';
		$this->data['c'] = 'room_type';
		$this->data['m'] = '';
		$this->data['page_desc'] = 'Control Panel';
		$this->load->model('room_type_m');
		
		
	}

	public function index(){
		
		$this->data['room_types'] = $this->room_type_m->get();		
		$this->data['subview'] = 'room_type/index';
		$this->load->view('layouts/_layout_main',$this->data);
	}


	public function ajax_add()
    {
        $this->_validate('create');
        $data = array(
                'room_type_name' => $this->input->post('room_type_name'),
                'room_type_desc' => $this->input->post('room_type_desc'),
               
            );
        $data['created_by'] = $this->session->userdata('user_id');
        $data['date_created'] = date('Y-m-d');
        $insert = $this->db->insert('room_types',$data);
        echo json_encode(array("status" => TRUE));
    }

    public function ajax_edit($id)
    {
        $data = $this->room_type_m->get($id);
        //$data->dob = ($data->dob == '0000-00-00') ? '' : $data->dob; // if 0000-00-00 set tu empty for datepicker compatibility
        echo json_encode($data);
    }

    public function ajax_update()
    {
        $this->_validate('update');
        $data = array(
                'room_type_name' => $this->input->post('room_type_name'),
                'room_type_desc' => $this->input->post('room_type_desc'),
               
            );
        $this->db->update('room_types', $data, array('room_type_id' => $this->input->post('id')));
       echo json_encode(array("status" => TRUE));
    }
 
    public function ajax_delete($id)
    {
        $this->room_type_m->delete($id);
        echo json_encode(array("room_type" => TRUE));
    }
	
	 private function _validate($method)
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['room_type'] = TRUE;
 
      
        if($this->input->post('room_type_name') == '')
        {
            $data['inputerror'][] = 'room_type_name';
            $data['error_string'][] = 'room_type Name is required';
            $data['room_type'] = FALSE;
        }else{
            if ($method == 'create') {
                $this->db->where('room_type_name',$this->input->post('room_type_name'));
                $x = count($this->room_type_m->get());
                if($x >= 1){
                    $data['inputerror'][] = 'room_type_name';
                    $data['error_string'][] = 'room_type Name  already Exists';
                    $data['room_type'] = FALSE;
                }
            }
        }

         if($this->input->post('room_type_desc') == '')
        {
            $data['inputerror'][] = 'room_type_desc';
            $data['error_string'][] = 'Description is required';
            $data['room_type'] = FALSE;
        }
 
        
 
        if($data['room_type'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }



}