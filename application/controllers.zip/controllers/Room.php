<?php 

class Room extends Admin_Controller{

	public function __construct(){
		parent::__construct();
		$this->data['page_title'] = 'Room Manager';
		$this->data['c'] = 'Control Panel';
		$this->data['m'] = '';
		$this->data['page_desc'] = 'Control Panel';
    $this->load->model('room_type_m');
    $this->load->model('room_m');
    $this->load->model('room_photo_m');
    $this->load->model('inclusion_m');
    $this->load->helper(array('form', 'url'));
		
	}

	public function index(){
    $this->data['page_desc'] = 'Room';
		$this->data['room_types'] = $this->room_type_m->get_room_types();
		$this->data['vacant'] = $this->room_m->get_vacant();
		$this->data['inclusions'] = $this->inclusion_m->get();
		$this->data['rooms'] = $this->room_m->get();
		$this->data['subview'] = 'room/room_list';
		$this->load->view('layouts/_layout_main',$this->data);
	}

  public function manager(){
    $this->data['room_types'] = $this->room_type_m->get_room_types();
    $this->data['vacant'] = $this->room_m->get_vacant();
    $this->data['occupied'] = $this->room_m->get_occupied();
    $this->data['inclusions'] = $this->inclusion_m->get();
    $this->data['rooms'] = $this->room_m->get();
    $this->data['subview'] = 'room/index';
    $this->load->view('layouts/_layout_main',$this->data);
  }
  public function profit_report($year){
       
        
        $data =array();
      $months = array('01','02','03','04','05','06','07','08','09','10','11','12',);
      //   $months = array('00','01','02','03','04','05','06','07','08','9','10','11',);
      $i=0;
        foreach($months as $m){
             $cost= $this->reservation_m->getMonthlyProfit($m,$year);
            array_push($data,array($i,$cost));
            $i=$i+1;

        }
   
        echo json_encode($data,true);

  }
  
  public function showAvailableRooms(){
  
   
    if($this->input->get('pax')!=NULL && $this->input->get('in')!=NULL && $this->input->get('out')!=NULL){

         $this->data['rooms']= $this->room_m->available_rooms($this->input->get('pax'),$this->input->post('in'),$this->input->get('out'));
         $this->data['pax'] = $this->input->get('pax');
         $this->data['in'] = date('Y-m-d', strtotime($this->input->get('in'))); 
         $this->data['out'] = date('Y-m-d', strtotime($this->input->get('out'))); 

            $_SESSION['pax'] = $this->input->get('pax');      
            $_SESSION["in"] =  $this->input->get('in');
            $_SESSION['out'] = $this->input->get('out');
    }
  
    else{
        $this->data['rooms']= $this->room_m->available_rooms('*','*','*');
        $this->data['pax'] = null;
        $this->data['in'] =null;
        $this->data['out'] =null;
       }
          
           
      
    $this->data['subview'] = 'room/room_list';
    $this->load->view('layouts/_layout_guest',$this->data);
  }
   public function showAvailability(){
  $room_id = $_SESSION['room_id'];
   
    if($this->input->get('pax')!=NULL && $this->input->get('in')!=NULL && $this->input->get('out')!=NULL){

         $availability= $this->room_m->isAvailable_room($this->input->get('pax'),$this->input->post('in'),$this->input->get('out'),$room_id);
         $this->data['pax'] = $this->input->get('pax');
       

         if($availability==1){

            $this->data['in'] = date('Y-m-d', strtotime($this->input->get('in'))); 
             $this->data['out'] = date('Y-m-d', strtotime($this->input->get('out'))); 
              $this->session->set_flashdata('message2','yes');


         }
         if($availability==0){

           
            $this->data['in'] = "";
            $this->data['out'] = "";
             $this->session->set_flashdata('message2','no');

          
         }

          $this->data['rooms']= $this->room_m->getRoom($room_id);
          $this->data['subview'] = 'room/bookroom';
          $this->load->view('layouts/_layout_guest',$this->data);

    }
     
 
  }
 
  public function bookRoom(){

        $room_id = $this->input->post('room_id');
        $this->data['rooms']= $this->room_m->getRoom($room_id);
        $this->data['pax'] = null;
        $this->data['in'] =null;
        $this->data['out'] =null;
        $_SESSION['room_id'] =$room_id;
        $this->data['subview'] = 'room/bookroom';
        $this->load->view('layouts/_layout_guest',$this->data);

  }

  public function ajax_edit($id)
    {

        $data = $this->room_m->getRoom($id);
        //$data->dob = ($data->dob == '0000-00-00') ? '' : $data->dob; // if 0000-00-00 set tu empty for datepicker compatibility
        echo json_encode($data);
    }

   
   public function getRandomCode(){
    $an = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    $su = strlen($an) - 1;
    return substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1) .
            substr($an, rand(0, $su), 1);
    }


  public function reserve(){

    $settings = $this->costumization_m->get(1);
    $data = array(
                'room_id' => $this->input->post('room_id'),
                'pax' => $this->input->post('_pax'),
                'firstname' => $this->input->post('fname'),
                'lastname' => $this->input->post('lname'),
                'checkin_date' => $this->input->post('_in'),
                'checkout_date' => $this->input->post('_out'),           
                'cost' => $this->input->post('total'),
                'night_no' => $this->input->post('night'),
                'quantity' => $this->input->post('quantity'),
                'phone' => $this->input->post('phone'),
                'email' => $this->input->post('email_add'),
                'reference_no' => $this->getRandomCode(),
              
             
               
            );
      $data['date_created'] = date('Y-m-d H:i:s');
       
      $insert = $this->db->insert('reservation',$data);
      $reservation_id = $this->db->insert_id();


       $data2 = array(
               
                'reservation_id' =>  $reservation_id,
               'status_id'  => 20,
              );
        $data2['date_created'] = date('Y-m-d');
         $insert = $this->db->insert('reservation_status',$data2);



          $data3 = array(
               
                'reservation_id' =>  $reservation_id,
               'invoice_date'  =>  date('Y-m-d'),
               'due_date'      =>  date('Y-m-d', strtotime('-'.$settings->days_before_duepayment.' day', strtotime($this->input->post('_in'))))
              );
       
         $insert = $this->db->insert('reservation_payment',$data3);
    
      $_SESSION["res_id"] = $reservation_id;
     redirect('room/findBooking/');
   
  }

  public function cancel_booking(){




     $data = array(
               
                'status_id' => 12,
               
            );
        $this->db->update('reservation_status', $data, array('reservation_id' => $this->input->post('reservation_id')));
       

    
     $_SESSION["res_id"] =  $this->input->post('reservation_id');
     redirect('room/findBooking/');


  }
  
  public function findBooking(){

    $this->data['m']= 'View Booking';
      if($this->input->post('viewbooking')){

        $ref_no = $this->input->post('res_id');
       $ref_id  = $this->reservation_m->getReservationByRefNo($ref_no);

       if($ref_id==null){



          redirect('auth/home');

       }
      }
      else{
       $ref_id= $_SESSION["res_id"];

      
      }
       $this->data['addons_availed']=  $this->addon_availed_m->getPackageAvailed($ref_id);
     $this->data['reservation']= $this->reservation_m->getReservation($ref_id);
      $this->data['addons']= $this->addon_m->get();
      $this->data['subview'] = 'guest/mybooking';
       $this->load->view('layouts/_layout_guest',$this->data);

  }
  public function updateRoom(){


    $data = array(
                'room_type_id' => $this->input->post('room_type_id'),
                'room_name' => $this->input->post('room_name'),
                'description' => $this->input->post('description'),
                'maximum_pax' => $this->input->post('maximum_pax'),           
                'rate_per_night' => $this->input->post('rate_per_night'),
              
             
               
            );
      
        $this->db->update('rooms', $data, array('room_id' => $this->input->post('room_id')));
       redirect('room/manager');


       redirect('room/manager');
  }
 
	public function add(){


		$data = array(
                'room_type_id' => $this->input->post('room_type_id'),
                'room_name' => $this->input->post('room_name'),
                'description' => $this->input->post('description'),
                'maximum_pax' => $this->input->post('maximum_pax'),           
             	  'rate_per_night' => $this->input->post('rate_per_night'),
              
             
               
            );
        $data['created_by'] = $this->session->userdata('user_id');
        $data['date_created'] = date('Y-m-d');
        $insert = $this->db->insert('rooms',$data);


        $room_id= $this->db->insert_id();
        $inclusions=  $this->input->post('inclusions');

        foreach($inclusions as $inclusion){
	        $data2 = array(
	                'room_id' => $room_id,
	                'inclusion_id' => $inclusion,
	                          
	        );
	        $data2['created_by'] = $this->session->userdata('user_id');
	        $data2['date_created'] = date('Y-m-d');
	        $insert = $this->db->insert('room_inclusions',$data2);
   		 }

      
      

   if(!empty($_FILES['attachments']))
        {
           $uploaded_files = $_FILES['attachments'];
            unset($_FILES);

            foreach ($uploaded_files as $desc => $arr) {
                foreach ($arr as $k => $string) {
                    $_FILES[$k][$desc] = $string;
                }
            }

            $this->load->library('upload');
            $config['upload_path'] = './upload/rooms/';
            $config['allowed_types'] = 'jpg|jpeg|png';
            $config['max_size']             = 10000; //set max size allowed in Kilobyte
            $config['max_width']            = 1000; // set max width image allowed
            $config['max_height']           = 1000; // set max height allowed

            $ctr=1;
            foreach ($_FILES as $k => $file) {
                 $path_info = pathinfo($file['name']);
                  $file_extension = $path_info['extension'];
                 // $file_extension = pathinfo($path, PATHINFO_EXTENSION);
              
                $config['file_name'] = $room_id. '_' . $ctr . '.'.$file_extension;

                $this->upload->initialize($config);

                $photo=$this->upload->do_upload($k);

                 $data3 = array(
                  'room_id' => $room_id,
                  'filename' => $room_id. '_' . $ctr . '.'.$file_extension,
                            
                  );
                  $data3['created_by'] = $this->session->userdata('user_id');
                  $data3['date_created'] = date('Y-m-d');
                  $insert = $this->db->insert('room_photos',$data3);
                $ctr=$ctr+1;

            }
   		 
        }
        
    
		redirect('room/manager');
		
	}
    
	
   public function setToVacant()
    {
       
         $data = array(
               
                'room_status_id' => 5,
               
            );
        $this->db->update('rooms', $data, array('room_id' => $this->input->post('room_id')));
        redirect('room/manager');
      
    }
   public function setToOccupied()
    {
       
         $data = array(
               
                  'room_status_id' => 1,
               
            );
        $this->db->update('rooms', $data, array('room_id' => $this->input->post('room_id')));
       redirect('room/manager');
    }
    public function ajax_delete($id)
    {
        $this->room_m->delete($id);
        echo json_encode(array("status" => TRUE));
    }
     public function delete($id)
    {
        $this->db->delete('rooms', array('room_id' => $id)); 
        redirect('room/manager');
    }
}