<?php 
class Event extends Admin_Controller{

	public function __construct(){
		parent::__construct();
		$this->data['page_title'] = 'Event';
		$this->data['c'] = 'event';
		$this->data['m'] = '';
		$this->data['page_desc'] = 'List of events';
		$this->load->model('event_m');
        $this->load->model('reservation_m');
        $this->load->model('event_type_m');
        $this->load->model('services_availed_m');
        $this->load->model('status_m');
        $this->load->model('client_m');
        $this->load->model('service_m');
        $this->load->model('null_date_m');
		
		
	}

	public function index(){
		$this->data['event_types'] = $this->event_type_m->get();
        $this->data['m'] = 'viewall';
	    $this->data['events'] = $this->event_m->getEvents();
        $this->data['status'] = $this->status_m->get_statuss();
		$this->data['subview'] = 'event/index';
		$this->load->view('layouts/_layout_main',$this->data);
	}

    public function planner($reservation_id){
        $this->data['page_title'] = 'Reservation';

        $reservation= $this->reservation_m->get($reservation_id);
        $this->data['reservation'] = $reservation;
        $this->data['event'] = $this->event_m->get($reservation->event_id);
      
        $this->data['services'] = $this->service_m->get();     
        $this->data['subview'] = 'event/planner';
        $this->data['reservation_id'] = $reservation_id;
        $this->load->view('layouts/_layout_main',$this->data);

    }
    public function forapproval(){
        $this->data['m'] = 'forapproval';
        $this->data['event_types'] = $this->event_type_m->get();
        $this->data['status'] = $this->status_m->get_statuss();
        $this->data['events'] = $this->event_m->getForApproval();
        $this->data['subview'] = 'event/index';
        $this->load->view('layouts/_layout_main',$this->data);
    }
     public function approved(){
         $this->data['m'] = 'approved';
        $this->data['event_types'] = $this->event_type_m->get();
       $this->data['events'] = $this->event_m->getApproved();
        $this->data['subview'] = 'event/index';
        $this->load->view('layouts/_layout_main',$this->data);
    }
    public function add(){

        if($this->input->post('submit') == "Book Event") { 
                
            $entry = array(             
                'event_type_id' => $this->input->post('event_type_id'),
                'event_title' => $this->input->post('event_title'),
                'event_date' =>  $this->input->post('event_date'),
                'event_time' =>  $this->input->post('event_time'),
                'event_venue' =>  $this->input->post('event_venue'),
                 'event_pax' =>  $this->input->post('event_pax'),
            );
        $entry['created_by'] = $this->session->userdata('user_id');
        $entry['date_created'] = date('Y-m-d');
        
         $this->db->insert('events',$entry);
         $event_id= $this->db->insert_id();
       
        $data =array(
            'event_id' =>  $event_id,
            'client_id' =>   $this->session->userdata('user_id'),
            'created_by' => $this->session->userdata('user_id'),
            'date_created' => date('Y-m-d'),
            'active' => 1,

        );
        $this->db->insert('reservation',$data);
            $reservation_id= $this->db->insert_id();

         $data2 =array(
            'reservation_id' =>  $reservation_id,
            'status_id' =>   5,
            'created_by' => $this->session->userdata('user_id'),
            'date_created' => date('Y-m-d'),
            'active' => 1,

        );
        
          $this->db->insert('reservation_status',$data2);
            
            if (!$this->ion_auth->is_admin()) {    
            redirect('event/mybookings');
            }
            else{
                redirect('event/forapproval');
            }
        }
    
        
    }
    public function calendar(){
        $this->data['ams'] = $this->availability_meter_m->get();     
        $this->data['null_dates'] = $this->null_date_m->getNullDates();      
        $this->data['subview'] = 'calendar/slot';
        $this->load->view('layouts/_layout_main',$this->data);
    }
    public function create(){
        $this->data['event_types'] = $this->event_type_m->get_event_types();
    
        $this->data['subview'] = 'event/create';
        $this->load->view('layouts/_layout_main',$this->data);
    }
    public function mybookings(){
         $user=$this->ion_auth->user()->row();


        $this->data['my_events'] = $this->event_m->getMyEvents($user->id);
        $this->data['subview'] = 'event/bookings';
        $this->load->view('layouts/_layout_main',$this->data);

    }
    public function changeStatus(){
        $date = $this->input->post('event_date');
        if($this->input->post('status_id')==1){

            if(!$this->null_date_m->ifDateExists($date)){
                 $data2 = array(              
                    'event_date' => $date,
                    'availability_meter' => 1,    
              );
               $insert = $this->db->insert('null_dates',$data2);


            }
                
            if($this->null_date_m->getNullDateByDate($date)->active==0){
                $data3 = array(
                 'status_id' => $this->input->post('status_id'),
                 );
                $this->db->update('reservation_status', $data3, array('reservation_status_id' => $this->input->post('reservation_status_id')));  
                $this->null_date_m->updateNullDate($date);


            }
            else{
                  
                  echo '<script>alert("Conflict detected, the chosen date is currently fully booked"); </script>';

            //  echo "<script type='text/javascript'>new PNotify({title: 'Conflict detected',text: 'The event date is currently fully booked',type: 'error'});</script>";
               

            
            }
        
       
    
        }
        else if($this->input->post('status_id')==5){
           $data3 = array(
                 'status_id' => $this->input->post('status_id'),
                 );
                $this->db->update('reservation_status', $data3, array('reservation_status_id' => $this->input->post('reservation_status_id')));  
                $this->null_date_m->updateNullDate($date);

          

        }         
          redirect('event/forapproval');  
    }


    public function invoice($id){
        $this->data['user'] = $this->ion_auth->get($id);
        $this->data['subview'] = 'event/invoice';
        $this->load->view('layouts/_layout_main',$this->data);
    }
    public function search_available(){
    
       $event_date = $this->input->post('event_date');
          
       $this->$data['null_dates'] = $this->event_m->search_availabilty(date($event_date));
       $this->data['event_types'] = $this->event_type_m->get_event_types();        
        $$this->load->view('auth/login',$this->data);

        
  redirect('event/index');
    }
	public function ajax_add()
    {
        $this->_validate('create');
        $data = array(
                'event_type_id' => $this->input->post('event_type_id'),
                'event_title' => $this->input->post('event_title'),
                'event_pax' => $this->input->post('event_pax'),
                'event_date' => $this->input->post('event_date'),
                'event_time' => $this->input->post('event_time'),
                'event_venue' => $this->input->post('event_venue'),
               
            );
        $data['created_by'] = $this->session->userdata('user_id');
        $data['date_created'] = date('Y-m-d');
        $insert = $this->db->insert('events',$data);
        echo json_encode(array("status" => TRUE));
    }

    public function ajax_edit($id)
    {
        $data = $this->event_m->get($id);
        //$data->dob = ($data->dob == '0000-00-00') ? '' : $data->dob; // if 0000-00-00 set tu empty for datepicker compatibility
        echo json_encode($data);
    }

    public function ajax_update()
    {
        $this->_validate('update');
        $data = array(
                'event_type_id' => $this->input->post('event_type_id'),
                'event_title' => $this->input->post('event_title'),
                'event_pax' => $this->input->post('event_pax'),
                'event_date' => $this->input->post('event_date'),
                'event_time' => $this->input->post('event_time'),
                'event_venue' => $this->input->post('event_venue'),
               
               
            );
        $this->event_m->save($data,$this->input->post('id'));
        echo json_encode(array("status" => TRUE));
    }
 
    public function ajax_delete($id)
    {
        $this->event_m->delete($id);
        echo json_encode(array("status" => TRUE));
    }
	public function _validate($method){
         if ($method == 'addToNullDates') {
         
                $x = count($this->event_m->getEventsByDate($this->input->post('event_date')));
                if($x > 1){
                    return 1;
                }
              else{
                    return 0;
                }
         }
          if ($method == 'checkLimit') {
       
                $x = ($this->null_date_m->getLimitByDate($this->input->post('event_date')));
                if($x > 1){
                    return 1;
                }
              else{
                    return 0;
                }
         }
         if ($method == 'getLimit') {
       
                $x = ($this->null_date_m->getLimitByDate($this->input->post('event_date')));
               return $x;
         }
         if ($method == 'getCurrentNumber') {
       
                $x = ($this->event_m->getEventsByDate($this->input->post('event_date')));
               return $x;
         }
    }
	
}

