<?php 

class Availability_meter extends Admin_Controller{

	public function __construct(){
		parent::__construct();
		$this->data['page_title'] = 'Availability Type';
		$this->data['c'] = 'availability_meter';
		$this->data['m'] = '';
		$this->data['page_desc'] = 'Date Availability Meter';
		$this->load->model('availability_meter_m');
		
		
	}

	public function index(){
		
		$this->data['availability_meter'] = $this->availability_meter_m->get();		
		$this->data['subview'] = 'availability_meter/index';
		$this->load->view('layouts/_layout_main',$this->data);
	}


	public function ajax_add()
    {
        
        $data = array(
                'am_description' => $this->input->post('am_desc'),
                'set_limit' => $this->input->post('set_limit'),
               
            );
        
        $insert = $this->db->insert('availability_meter',$data);
        echo json_encode(array("availability_meter" => TRUE));
    }

    public function ajax_edit($id)
    {
        $data = $this->availability_meter_m->get($id);
        //$data->dob = ($data->dob == '0000-00-00') ? '' : $data->dob; // if 0000-00-00 set tu empty for datepicker compatibility
        echo json_encode($data);
    }

    public function ajax_update()
    {
        $this->_validate('update');
        $data = array(
                'am_description' => $this->input->post('am_desc'),
                'am_color' => $this->input->post('am_color'),
                'set_limit' => $this->input->post('set_limit'),
               
            );
        $this->availability_meter_m->save($data,$this->input->post('id'));
        echo json_encode(array("availability_meter" => TRUE));
    }
 
    public function ajax_delete($id)
    {
        $this->availability_meter_m->delete($id);
        echo json_encode(array("availability_meter" => TRUE));
    }
	
	



}