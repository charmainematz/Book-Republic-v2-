<?php 

class Inclusion extends Admin_Controller{

	public function __construct(){
		parent::__construct();
		$this->data['page_title'] = 'Inclusion';
		$this->data['c'] = 'inclusion';
		$this->data['m'] = '';
		$this->data['page_desc'] = 'Control Panel';
		$this->load->model('inclusion_m');
		
		
	}

	public function index(){
		
		$this->data['inclusions'] = $this->inclusion_m->get();		
		$this->data['subview'] = 'inclusion/index';
		$this->load->view('layouts/_layout_main',$this->data);
	}


	public function ajax_add()
    {
        $this->_validate('create');
        $data = array(
                'inclusion_name' => $this->input->post('inclusion_name'),
                'inclusion_desc' => $this->input->post('inclusion_desc'),
               
            );
        $data['created_by'] = $this->session->userdata('user_id');
        $data['date_created'] = date('Y-m-d');
        $insert = $this->db->insert('inclusions',$data);
        echo json_encode(array("status" => TRUE));
    }

    public function ajax_edit($id)
    {
        $data = $this->inclusion_m->get($id);
      
        echo json_encode($data);
    }
     public function ajax_getInclusions($room_id)
    {
        $inclusions = $this->inclusion_m->getInclusions($id);
      
        echo json_encode($inclusions);
    }

    public function ajax_update()
    {
        $this->_validate('update');
        $data = array(
                'inclusion_name' => $this->input->post('inclusion_name'),
                'inclusion_desc' => $this->input->post('inclusion_desc'),
               
            );
        $this->db->update('inclusions', $data, array('inclusion_id' => $this->input->post('id')));
      
        echo json_encode(array("status" => TRUE));
    }
 
    public function ajax_delete($id)
    {
        $this->inclusion_m->delete($id);
        echo json_encode(array("inclusion" => TRUE));
    }
	
	 private function _validate($method)
    {
        $data = array();
        $data['error_string'] = array();
        $data['inputerror'] = array();
        $data['inclusion'] = TRUE;
 
      
        if($this->input->post('inclusion_name') == '')
        {
            $data['inputerror'][] = 'inclusion_name';
            $data['error_string'][] = 'inclusion Name is required';
            $data['inclusion'] = FALSE;
        }else{
            if ($method == 'create') {
                $this->db->where('inclusion_name',$this->input->post('inclusion_name'));
                $x = count($this->inclusion_m->get());
                if($x >= 1){
                    $data['inputerror'][] = 'inclusion_name';
                    $data['error_string'][] = 'inclusion Name  already Exists';
                    $data['inclusion'] = FALSE;
                }
            }
        }

         if($this->input->post('inclusion_desc') == '')
        {
            $data['inputerror'][] = 'inclusion_desc';
            $data['error_string'][] = 'Description is required';
            $data['inclusion'] = FALSE;
        }
 
        
 
        if($data['inclusion'] === FALSE)
        {
            echo json_encode($data);
            exit();
        }
    }



}