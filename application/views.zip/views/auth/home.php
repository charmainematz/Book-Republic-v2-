<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="en">
<head>
<title><?= $app_title?> </title>
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Resort Inn Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
    function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="<?=site_url('css/bootstrap.css')?>" rel="stylesheet" type="text/css" media="all">
<link href="<?=site_url('fonts/css/font-awesome.css')?>" rel="stylesheet">
<link href="<?=site_url('css/chocolat.css')?>" rel="stylesheet" type="text/css" media="screen">
<link href="<?=site_url('css/easy-responsive-tabs.css')?>" type='text/css' rel="stylesheet">
<link href="<?=site_url('css/flexslider.css')?>" rel="stylesheet" type="text/css" media="screen" property="">
<link href="<?=site_url('css/jquery-ui.css')?>" rel="stylesheet">
<link href="<?=site_url('css/style.css')?>" rel="stylesheet" type="text/css" media="all">
 <link rel="stylesheet"  href="<?=site_url('assets/css/daterangepicker.css')?>">
<link rel="stylesheet"  href="<?=site_url('assets/vendor/datepicker/daterangepicker.min.css')?>">

 <script src="<?=site_url('js/home/modernizr-2.6.2.min.js')?>" ></script>
 
  <link rel="stylesheet" href="<?=site_url('assets/fonts/web-icons/web-icons.min.css')?>">


 <link rel="stylesheet" href="<?=site_url('assets/vendor/slick-carousel/slick.css')?>">

 <style>
 body{

    height:100%;
    width:100%;
 }
      img{
           margin: auto;

      
      }
      .price-grid{
          height: 500px;
      
      }
    .item{

      
        height: 250px;
        max-height: 100%;
    }
    .items {
      width: 100%;
    }
    
    .owl-carousel-shortcode .item {
      text-align: center;
    }
    
    .slider {
      margin: 0 0 0 0;
       max-height: 100%;
      text-align: center;
    }
    
    .slider img {
      width: 100%;
      border: 5px solid #fff;
    }
    
    .slider h3 {
      position: relative;
      padding: 10px;
      margin: 0 10px;
      font-size: 36px;
      line-height: 100px;
      background: #f3f7f9;
    }
    
    #exampleCenter h3 {
      opacity: .5;
      -webkit-transition: all 300ms ease;
      -o-transition: all 300ms ease;
      transition: all 300ms ease;
      -webkit-transform: scale(.95);
      -ms-transform: scale(.95);
      -o-transform: scale(.95);
      transform: scale(.95);
    }
    
    #exampleCenter .slick-center h3 {
      color: #f2a654;
      opacity: 1;
      -webkit-transform: scale(1.08);
      -ms-transform: scale(1.08);
      -o-transform: scale(1.08);
      transform: scale(1.08);
    }
  </style>
<!--fonts-->
<link href="//fonts.googleapis.com/css?family=Oswald:300,400,700" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Federo" rel="stylesheet">
<link href="//fonts.googleapis.com/css?family=Lato:300,400,700,900" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lovers+Quarrel" rel="stylesheet">
<!--//fonts-->
</head>
<body>
<!-- header -->
<div class="banner-top">
      
      
      <div class="clearfix"></div>
    </div>
  <div id = "banner1" class="w3_navigation">
    <div class="container">
      <nav style="background-color: #867666" class="navbar navbar-default">
        <div class="navbar-header navbar-left">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <h1><a class="navbar-brand" href="<?=site_url('auth/home')?>"><?=$hotel->hotel_name;?></span><p class="logo_w3l_agile_caption"><?=$hotel->sub_name?></p></a></h1>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
          <nav class="menu menu--iris">
            <ul class="nav navbar-nav menu__list">
               <li class="menu__item menu__item--current"><a href="<?=site_url('room/showAvailableRooms')?>" class="menu__link">Book Now</a></li>
                <li class="menu__item"><a href="#about_hotel" class="menu__link scroll">About</a></li>
               <li class="menu__item"><a href="#rooms" class="menu__link scroll">Rooms</a></li>
             
              <li class="menu__item"><a href="#amenities" class="menu__link scroll">Amenities</a></li>
             
              
             
              <li class="menu__item">
                 
                <?php if (!$this->ion_auth->logged_in()){?>
                      <a href="#" data-toggle="modal" data-target="#login" class="menu__link scroll">Manage Booking</a>
                  <?php }else{?>
                    <a href="<?=site_url('dashboard')?>">Manage Booking</a>
                    <?php }?>
              </li>
              </ul>
          </nav>
        </div>
      </nav>

    </div>
  </div>

</div>
<!-- //header -->
    <!-- banner -->
  <div id="home" class="w3ls-banner"  style="height:100%;width: 100%">
    <!-- banner-text -->
    <div class="slider">
      <div class="callbacks_container">
        <ul class="rslides callbacks callbacks1" id="slider4">
          <li>
            <div class="w3layouts-banner-top">

              <div class="container">
                <div class="agileits-banner-info">
               <!-- <h4>STAYCATION</h4>
                  <h3>awaits you.</h3>
                    <p>Book now.</p>-->
                  <div class="agileits_w3layouts_more menu__item">
        <a class="acive" href="#" class="menu__link" data-toggle="modal" data-target="#myModal"><h2>Your Best Staycation Awaits...</h2></a>
      </div>
                </div>  
              </div>
            </div>
          </li>
          <li>
            <div class="w3layouts-banner-top w3layouts-banner-top1">
              <div class="container">
                <div class="agileits-banner-info">
              <!-- <h4>Star Hotel</h4>
                  <h3>Stay with friends & families</h3>
                    <p>Come & enjoy precious moment with us</p>-->
                  <div class="agileits_w3layouts_more menu__item">
        <a href="#" class="menu__link" data-toggle="modal" data-target="#myModal">Relaxing Ambience</a>
      </div>
                </div>  
              </div>
            </div>
          </li>
          <li>
            <div class="w3layouts-banner-top w3layouts-banner-top2">
              <div class="container">
                <div class="agileits-banner-info">
                  <!--
                <h4>Need some R & R?</h4>
                <h3>S right at your fingertips.</h3>
                    <p>Book now.</p>-->
                  <div class="agileits_w3layouts_more menu__item">
                      <a href="#" class="menu__link" data-toggle="modal" data-target="#myModal">Affordable Gourmet Food</a>
                    </div>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </div>
      <div class="clearfix"> </div>
      <!--banner Slider starts Here-->

      
  </div>  
  <!-- //banner --> 
<!--//Header-->
<!-- //Modal1 -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" >
            <!-- Modal1 -->
              <div class="modal-dialog">
              <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4><?=$hotel->hotel_name;?> <span><?=$hotel->sub_name;?></span></h4>
                    <img src="<?=site_url('images/1.jpeg')?>" alt=" " class="img-responsive">
                    <h5>We know what you love</h5>
                    <p>Providing guests unique and enchanting views from their rooms with its exceptional amenities, makes Star Hotel one of bests in its kind.Try our food menu, awesome services and friendly staff while you are here.</p>
                  </div>
                </div>
              </div>
            </div>
 <div id="login" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" >
    <div class="modal-dialog modal-md">
      <div class="modal-content">

  
        <div class="row modal-body" style="background-color:  #2f3131;">    
            <div class="col-lg-6"> 
           <?php $this->load->view('auth/login_form')?>

           
            <p style="color: #E1B80D">Forgot password? 
              <a href="<?=site_url('auth/forgot_password')?>" > Reset password.</a> 
            </p>
          </div>
            <div class="col-lg-6" style="border-left:1px solid #fff;height:300px">
              
              <h4 style="color: #E1B80D">Booking Details</h4>
                <form action="<?=site_url('room/findBooking')?>" method="post">
               <div class="form-group">
                  <p style="color: #E1B80D">Booking Reference Number</p>

                  <input type="text" class="form-control" name="res_id" required>
                 
                </div>
                   
                   <br>
                   <button type="submit" name="viewbooking" value="viewbooking" class="btn btn-warning">Find Booking </button>
            <?= form_close(); ?>
            

            </div>
        </div>
       
      </div>
    </div>
</div>
<div id="register" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true" >
    <div class="modal-dialog modal-sm">
      <div class="modal-content">

  
        <div class="modal-body" style="background-color:  #2f3131;">     
           <h4 style="color: #E1B80D">Registration</h4>
           <?php $this->load->view('auth/signup_form')?>
           
        </div>
       
      </div>
    </div>
</div>


<div id="availability-agileits">

<div class="col-md-12 book-form">
  
              
   
       
          <form action="<?=site_url('room/showAvailableRooms')?>" method="GET" novalidate>   
          <div class="fields-w3ls form-left-agileits-w3layouts ">
              <p style="color: #E1B80D">No. of Guest</p>
              
                 <select name="pax" class="form-control">
                         
                          <option value="1">1 adult</option>
                          <option value="2">2 adults</option>
                          <option value="3">3 adults</option>
                          <option value="4">4 adults</option>
                          <option value="5">5 adult</option>
                          <option value="6">6 adults</option>
                          <option value="7">7 adults</option>
                          <option value="8">8 adults</option>
                          <option value="9">9 adult</option>
                          <option value="10">10 adults</option>
                          <option value="11">11 adults</option>
                          <option value="12">12 adults</option>
                          <option value="13">13 adult</option>
                          <option value="14">14 adults</option>
                          <option value="15">15 adults</option>
                       
                          
      </select>
    </div>
      <span id="two-inputs">
            <form>
          <div class="fields-w3ls form-date-w3-agileits">
                    <p style="color: #E1B80D">Arrival Date</p>
                  <input  id="checkin" name="in" type="text" value="Select Date" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'mm/dd/yyyy';}" required="">
          </div>
          <div class="fields-w3ls form-date-w3-agileits">
              <p style="color: #E1B80D">Departure Date</p>
            <input id="out" name="out" type="text" value="Select Date" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'mm/dd/yyyy';}" required="">
          </div>
          
       
              <!-- <h4>Star Hotel</h4>
                  <h3>Stay with friends & families</h3>
                    <p>Come & enjoy precious moment with us</p>-->
             <div class="fields-w3ls form-left-agileits-w3layouts" style="text-align:center">
              <p style="color: #E1B80D">Check Availability</p>
              
          
              <button name="homebutton" value="viewAvailability"   onclick="this.form.submit()" class="btn btn-warning">Show Rooms </button>
          </div>
           </form>
      </span>           
             
       
      </div>
      <div class="clearfix"> </div>
        
</div>
 
<section  class="contact-w3ls" id="rooms" style="height:100%; width: 100%;" >
 
  <div class="container contact-w3-agile2"> 
      
         <h4>Rooms And Rates</h4>
         
      <div style="background-color:white" class="col-lg-12 contact-agileits " >
                    <!-- Example Lazy Loading -->

                  <!--   class="example slider" id="exampleLazy" -->
        <div id="exampleLazy"  >
            
            <?php 
                  
                  foreach($rooms as $room):
                  $file= $this->room_photo_m->get_cover_photo($room->room_id);
                  if($file==""){ $file = 'coming_soon.png'; } 


                  ?>
                    


                    <div style="max-height:300px; " class="col-md-3 price-grid"  >
                      <div class="price-block agile"     >
                        <div class="item price-gd-top" style="height:180px;background-color: #877666">
                        <img  class="img-responsive" style="height:180px; width:180px" data-lazy="<?=site_url('upload/rooms/'.$file)?>" alt=" " class="img-responsive" />                      
                        </div>
                       
                        <div class="price-gd-bottom"  style="height:120px;text-align: center;">
                           <h5 style="font-size: 20px;text-align: center;"><?=$room->room_name?></h5>
                          <div  style="font-size: 10px" class="price-list"></div>
                          <div  style="font-size: 12px"  class="price-selet"> 
                            <h3><?="Php ".$room->rate_per_night?> </h3>

                            <form method="post" action="<?=site_url('room/bookRoom')?>">
                              <input type="hidden" name="room_id" value="<?=$room->room_id?>">
                            <input type="button" value="Book now" name="book_this" onclick="this.form.submit()" style="font-size: 15px"> 
                           </form>
                          </div>
                        </div>
                      </div>
                    </div>
                
              <?php endforeach;?>
          </div>
      </div>

             
      <div class="clearfix"> </div>
      <div style="text-align: center" class="agileits_w3layouts_more menu__item">                   
          <a href="#amenities" class="menu__link scroll" >View Amenities</a>                     
      </div>
  </div>
  
   <!--// rooms & rates -->
 </section>


<!-- contact -->
<section class="contact-w3ls" id="amenities" style="height:100%;width: 100%" >
  <div class="container" >
    <div class="col-lg-12 col-md-12 col-sm-12 contact-w3-agile2" >
        <h4>Our Facilities</h4>
      <div class="contact-agileits">
      <div class="row" style="text-align: center; width: 100%">
        <br><br>
         <?php foreach($facilities as $facility):?>
      
         
        <div class="col-md-4" style="height: 200px">
          <h2 style="color: #E1B80D"><?=$facility->facility_name?> </h2>
          <p style="color:#EAE2D6; text-align: justify;"><?=$facility->facility_desc?> </p>
         
        </div>
         <?php endforeach;?> 
      </div>
      
      </div>
      <br>
   
          
     <hr>
  </div>
     <div style="text-align: center" class="agileits_w3layouts_more menu__item">               
      <br><br><br><br>
      <a href="#contact" class="menu__link scroll" >Inquire Now</a>                    
      </div>

    <div class="clearfix"></div>
  </div>
</section>
<section class="contact-w3ls" id="about_hotel" style="height:100%;width: 100%" >
  <div class="container" >
    <div class="col-lg-12 col-md-12 col-sm-12 contact-w3-agile2" >
        <h4>About</h4>
      <div class="contact-agileits">
      <div class="row" style="text-align: center;">
        <br><br>
       
      
         
        <div class="col-md-12">
          <h2 style="color: #E1B80D"><?=$hotel->hotel_name." ".$hotel->sub_name?> </h2><br><br>
          <p style="color:#EAE2D6; text-align: center;"><?=$hotel->about?></p>
         
        </div>
        
      </div>
      
      </div>
      <br>
   
          
     <hr>
  </div>
     <div style="text-align: center" class="agileits_w3layouts_more menu__item">
                
       <br><br><br><br>
                      <a href="#contact" class="menu__link scroll" >Inquire Now</a>
                     
                    </div>

    <div class="clearfix"></div>
  </div>
</section>

<!-- /contact -->
<!-- contact -->
<section class="contact-w3ls" id="contact" >
  <div class="container" >
              <h4>Contact Us</h4>
            <div class="contact-agileits">
              
              <div class="row">
         
          <div class="col-md-6">
            <div class="col-md-2"></div>
        <div class="col-md-10">
         <?php if($this->session->flashdata('message')) {
            $message = $this->session->flashdata('message'); ?>
            <div class="alert alert-success alert-dismissible" >
               
             <?php echo $message; ?>
               
             </div>
        <?php } ?>
          <form action="<?=site_url('guest/inquire')?>" method="POST" novalidate>
            <div class="control-group form-group">
                          <div class="controls">
                              <label class="contact-p1">Full Name:</label>
                              <input type="text" class="form-control" name="name" id="name" required data-validation-required-message="Please enter your name.">
                              <p class="help-block"></p>
                          </div>
                      </div>  
                      <div class="control-group form-group">
                          <div class="controls">
                              <label class="contact-p1">Phone Number:</label>
                              <input type="tel" class="form-control" name="phone" id="phone" required data-validation-required-message="Please enter your phone number.">
                <p class="help-block"></p>
              </div>
                      </div>
                      <div class="control-group form-group">
                          <div class="controls">
                              <label class="contact-p1">Email Address:</label>
                              <input type="email" class="form-control" name="email" id="email" required data-validation-required-message="Please enter your email address.">
                <p class="help-block"></p>
              </div>
                      </div>
                       <div class="control-group form-group">
                          <div class="controls">
                              <label class="contact-p1">Inquiry:</label><br>
                             <textarea  id="message" name="message" style="background-color: transparent; color:white" class="form-control" rows="5"></textarea>
                <p class="help-block"></p>
              </div>
                      </div>
                      <div id="success"></div>
                      <!-- For success/fail messages -->

                     <button name="homebutton" value="inquire"   onclick="this.form.submit()" class="btn btn-warning">Submit Inquiry </button>
          </form>    
        </div>
          </div>      
          <div class="col-md-6">
           
            <p class="contact-agile1"><strong>Phone :</strong><?=$hotel->telephone?></p>
          <p class="contact-agile1"><strong>Email :</strong> <a href="#"><?=$hotel->email?></a></p>
          <p class="contact-agile1"><strong>Address :</strong> <?=$hotel->address?></p>
                                    
          <div class="social-bnr-agileits footer-icons-agileinfo">
            <ul class="social-icons3">
                    <li><a href="<?=$hotel->facebook?>" class="fa fa-facebook icon-border facebook"> </a></li>
                    <li><a href="<?=$hotel->twitter?>"  class="fa fa-twitter icon-border twitter"> </a></li>
                 
                  </ul>

          </div>
          <br>
          <div style="width: auto;max-height: auto">
            <?= $hotel->map?>
          </div>
        </div>
        <hr>
   
     
     
  </div>

    <div class="clearfix"></div>
  </div>
</section>
<!-- /contact -->
      <div class="copy" style="background-color: #2f3131">
        
   

            <p><?="© ".date('Y')." ".$hotel->hotel_name." ".$hotel->sub_name;?></p>
        </div>
<!--/footer -->
<!-- js -->
 <script src="<?=site_url('js/home/jquery-2.1.4.min.js')?>" ></script>

<!-- contact form -->
 <script src="<?=site_url('js/home/jqBootstrapValidation.js')?>" ></script>
<script src="<?=site_url('js/home/contact_me.js')?>" ></script>

<!-- /contact form -->  
<!-- Calendar -->
<script src="<?=site_url('js/home/jquery-ui.js')?>" ></script>
    
    <script>
        $(function() {
        $( "#datepicker,#datepicker1,#datepicker2,#datepicker3" ).datepicker();
        });
    </script>
<!-- //Calendar -->
<!-- gallery popup -->
 <link rel="stylesheet" href="<?=site_url('css/swipebox.css')?>" >
<script src="<?=site_url('js/home/jquery.swipebox.min.js')?>" ></script>

      
          <script type="text/javascript">
            jQuery(function($) {
              $(".swipebox").swipebox();
            });
          </script>
<!-- //gallery popup -->
<!-- start-smoth-scrolling -->
<script src="<?=site_url('js/home/move-top.js')?>" ></script>
<script src="<?=site_url('js/home/easing.js')?>" ></script>


<script type="text/javascript">
  jQuery(document).ready(function($) {
    $(".scroll").click(function(event){   
      event.preventDefault();
      $('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
    });
  });
</script>
<!-- start-smoth-scrolling -->
<!-- flexSlider -->
<script src="<?=site_url('js/home/jquery.flexslider.js')?>" ></script>
      
        <script type="text/javascript">
        $(window).load(function(){
          $('.flexslider').flexslider({
          animation: "slide",
          start: function(slider){
            $('body').removeClass('loading');
          }
          });
        });
        </script>
      <!-- //flexSlider -->
      <script src="<?=site_url('js/home/responsiveslides.min.js')?>" ></script>

      <script>
            // You can also use "$(window).load(function() {"
            $(function () {
              // Slideshow 4
              $("#slider4").responsiveSlides({
              auto: true,
              pager:true,
              nav:false,
              speed: 500,
              namespace: "callbacks",
              before: function () {
                $('.events').append("<li>before event fired.</li>");
              },
              after: function () {
                $('.events').append("<li>after event fired.</li>");
              }
              });
          
            });
      </script>
    <!--search-bar-->
      <script src="<?=site_url('js/home/main.js')?>" ></script>
 
<!--//search-bar-->
<!--tabs-->
  <script src="<?=site_url('js/home/easy-responsive-tabs.js')?>" ></script>
  <script  src="<?=site_url('assets/vendor/slidepanel/jquery-slidePanel.js')?>" ></script>
  <script src="<?=site_url('assets/vendor/owl-carousel/owl.carousel.js')?>" ></script>
  <script src="<?=site_url('assets/vendor/slick-carousel/slick.js')?>" ></script>
  <script src="<?=site_url('assets/js/site.js');?>"></script>
  <script  src="<?=site_url('assets/vendor/datepicker/jquery.daterangepicker.min.js')?>"></script>
  <script  src="<?=site_url('assets/vendor/moment/moment.min.js')?>"></script>

<script>

$(document).ready(function () {


      $('#exampleLazy').slick({
          lazyLoad: 'ondemand',
          slidesToShow: 3,
          slidesToScroll: 1,
          rows: 2,
        });

        // Example Slick Autoplay
        // ----------------------
       


          $('#horizontalTab').easyResponsiveTabs({
          type: 'default', //Types: default, vertical, accordion           
          width: 'auto', //auto or any width like 600px
          fit: true,   // 100% fit in a container
          closed: 'accordion', // Start closed if in accordion view
          activate: function(event) { // Callback function if tab is switched
          var $tab = $(this);
          var $info = $('#tabInfo');
          var $name = $('span', $info);
          $name.text($tab.text());
          $info.show();
          }
          });
          $('#verticalTab').easyResponsiveTabs({
          type: 'vertical',
          width: 'auto',
          fit: true
          });

       $('input[name="in"]').daterangepicker({
          autoUpdateInput: false,
          locale: {
              cancelLabel: 'Clear'
          }
       });

      $('input[name="in"]').on('apply.daterangepicker', function(ev, picker) {


          $(this).val(picker.startDate.format('YYYY-MM-DD'));
          $('#out').val(picker.endDate.format('YYYY-MM-DD'));

      });

  $('input[name="in"]').on('cancel.daterangepicker', function(ev, picker) {
      $(this).val('');
  });



});
</script>
<!--//tabs-->
<!-- smooth scrolling -->
  <script type="text/javascript">
    $(document).ready(function() {
    /*
      var defaults = {
      containerID: 'toTop', // fading element id
      containerHoverID: 'toTopHover', // fading element hover id
      scrollSpeed: 1200,
      easingType: 'linear' 
      };
    */                
    $().UItoTop({ easingType: 'easeOutQuart' });
    });

  });
  </script>
  
  <div class="arr-w3ls">
  <a href="#home" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
  </div>
<!-- //smooth scrolling -->

 <script src="<?=site_url('js/home/bootstrap-3.1.1.min.js')?>" ></script>
    <script  src="<?=site_url('assets/vendor/datepicker/moment.js')?>"></script>
  <script  src="<?=site_url('assets/vendor/datepicker/daterangepicker.js')?>"></script>
</body>
</html>