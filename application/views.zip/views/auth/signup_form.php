
    <?= form_open('auth/home','class = "sign-box" '); ?>
          
     
         <fieldset class="form-group ">
           
              <p style="color: #E1B80D">Username *</p>
         <?php if($identity_column=='username') {
                    echo form_input($identity,'','class = "form-control"');
                  } ?>
              
          
          <i class="font-icon font-icon-user"></i>
      </fieldset>
     

    
       <fieldset class="form-group ">
          
            <p style="color: #E1B80D">Email *</p>
         <?php echo form_input($email,'','class = "form-control"');?>  
           
        <i class="font-icon font-icon-lock"></i>
        </fieldset>
    
       
       <fieldset class="form-group ">
          <p style="color: #E1B80D">Password *</p>
     
           <?php echo form_input($password,'','class = "form-control"');?>  
           
        <i class="font-icon font-icon-lock"></i>
        </fieldset>
    
       
      <fieldset class="form-group ">
          <p style="color: #E1B80D">Confirm Password *</p>
        
               <?php echo form_input($password_confirm,'','class = "form-control"');?>  
           
        <i class="font-icon font-icon-lock"></i>
      </fieldset>
     
      <br>
        <button type="submit" name="homebutton" value="signup" class="btn btn-warning"> Register</button>
      <!-- <p class="sign-note">New to our website? <a href="sign-up.html">Sign up</a></p> -->
      <!--<button type="button" class="close">
          <span aria-hidden="true">&times;</span>
      </button>-->
      <?= form_close(); ?>