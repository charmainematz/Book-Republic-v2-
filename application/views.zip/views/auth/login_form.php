 <h4 style="color: #E1B80D">Member's Login</h4>
            <?= form_open('auth/home','class = "sign-box" '); ?>
                <?php if ($message): ?>
                <div class="alert alert-danger alert-fill alert-close alert-dismissible fade in" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                   <?php echo $message;?>
                </div>
                 <?php endif ?>
                  <div class="form-group">
                     <p style="color: #E1B80D">Username</p>
                    <?php echo form_input($identity,'','class = "form-control" placeholder = "Username" required');?>
                    <i class="font-icon font-icon-user"></i>                            
                </div>
                 <div class="form-group">
                  <p style="color: #E1B80D">Password</p>
                    <?php echo form_input($password,'','class = "form-control" placeholder = " Password" required' );?>
                    <i class="font-icon font-icon-lock"></i>
                
                  </div>
                  <br>
           
                   <button type="submit" name="homebutton" value="login" class="btn btn-warning">Log in </button>
            <?= form_close(); ?>

            