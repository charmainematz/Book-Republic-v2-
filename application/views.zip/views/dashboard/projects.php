<div role="tabpanel" class="tab-pane" id="tabs-2-tab-3">
								<section class="box-typical box-typical-padding">
									Projects
								</section>
							</div><!--.tab-pane-->