

    <div class="page-header padding-0" >
      <div class="widget widget-article type-flex">
        <div class="widget-header cover overlay">
            
                          
          <img style="  opacity: 0.4; filter: alpha(opacity=50); " class="cover-image height-300" 
            src="<?=site_url('assets/example-images/dashboard-header.jpg?'.rand()
            )?>" alt="">
           
          <div class="overlay-panel text-center vertical-align">
      
            <div class="widget-metas vertical-align-middle blue-grey-800 ov">
              
              <div class="widget-title font-size-40 margin-bottom-40   blue-grey-800"><br>
                <strong>iHotel</strong> <p>Management System</p>
              </div>
              
              <ul class="list-inline font-size-14">
              	<li>
                      <div id="clock">  </div>
                    </li>
                     <li>
                  <i class="icon wb-calendar margin-right-5" aria-hidden="true"></i> <?=date("M-d-y")?>
                </li>
                <li>
                  <i class="icon wb-map margin-right-5" aria-hidden="true"></i> Los Baños, Laguna
                </li>
                
             
        
                <li>
                   <div class="example-wrap">
                    <button type="button" class="btn btn-icon btn-dark btn-outline btn-round" data-plugin="toolbar"
                    data-toolbar="#user-options" data-toolbar-style="dark">
                      <i class="icon wb-settings" aria-hidden="true"></i>
                    </button>
                  </div>
          
                 </li>
              </ul>
            <div class="toolbar-icons hidden" id="user-options">
                    <form id="form" action="<?=site_url('dashboard/upload')?>" method="post" enctype="multipart/form-data">
                      <input  name="photo" type="file" style="display:none" id="imgupload">
                    </form>
                      <a onclick="upload()"><i class="icon wb-upload" aria-hidden="true"></i> </a>
                      <a href="<?=site_url('costumization')?>"><i class="icon wb-edit" aria-hidden="true"></i></a>
                   
                    
                  </div>
          </div>
          
          
                  
        </div>
      </div>
    </div>
    <div class="page-content container-fluid">
      <div class="row" data-plugin="matchHeight" data-by-row="true">
        <div class="col-xlg-3 col-lg-4 col-md-12">
          <!-- Panel Web Designer -->
        
              <!-- Widget -->
              <div class="widget">
                <div class="widget-content widget-radius padding-30 bg-white clearfix">
                  <div class="counter counter-md pull-left text-left">
                    <div class="counter-number-group">
                      <span class="counter-number"><?=count($occupied)."/".count($rooms)?> </span>
                      <span class="counter-number-related text-capitalize">Rooms</span>
                    </div>
                    <div class="counter-label text-capitalize font-size-16">occupied</div>
                  </div>
                  <div class="pull-right white">
                    <i class="icon icon-circle icon-2x wb-users bg-blue-600" aria-hidden="true"></i>
                  </div>
                </div>
            
              <!-- End Widget -->
            </div>
            </div>
             <div class="col-xlg-3 col-lg-4 col-md-12">
          <!-- Panel Web Designer -->
        
              <!-- Widget -->
              <div class="widget">
                <div class="widget-content widget-radius padding-30 bg-white clearfix">
                  <div class="counter counter-md pull-left text-left">
                    <div class="counter-number-group">
                      <span class="counter-number"><?=count($checkouts)?></span>
                      <span class="counter-number-related text-capitalize">Rooms</span>
                    </div>
                    <div class="counter-label text-capitalize font-size-16">For Check out</div>
                  </div>
                  <div class="pull-right white">
                    <i class="icon icon-circle icon-2x wb-users bg-blue-600" aria-hidden="true"></i>
                  </div>
                </div>
            
              <!-- End Widget -->
            </div>
            </div>
             <div class="col-xlg-3 col-lg-4 col-md-12">
          <!-- Panel Web Designer -->
        
              <!-- Widget -->
              <div class="widget">
                <div class="widget-content widget-radius padding-30 bg-white clearfix">
                  <div class="counter counter-md pull-left text-left">
                    <div class="counter-number-group">
                      <span class="counter-number"><?=count($checkins)?></span>
                      <span class="counter-number-related text-capitalize">Rooms</span>
                    </div>
                    <div class="counter-label text-capitalize font-size-16">For Check in</div>
                  </div>
                  <div class="pull-right white">
                    <i class="icon icon-circle icon-2x wb-users bg-blue-600" aria-hidden="true"></i>
                  </div>
                </div>
            
              <!-- End Widget -->
            </div>
            </div>
          </div>
          <!-- End Panel Web Designer -->

          <?php $this->load->view('dashboard/analytics')?>


      </div>
    </div>
  </div>
  <!-- End Page -->
 