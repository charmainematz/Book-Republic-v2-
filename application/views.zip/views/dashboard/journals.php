<div role="tabpanel" class="tab-pane active" id="tabs-2-tab-1">
								<article class="box-typical profile-post">
									<div class="profile-post-header">
										<div class="user-card-row">
											<div class="tbl-row">
												<div class="tbl-cell tbl-cell-photo">
													<a href="#">
														<img src="img/photo-64-2.jpg" alt="">
													</a>
												</div>
												<div class="tbl-cell">
													<div class="user-card-row-name"><a href="#">Tim Collins</a></div>
													<div class="color-blue-grey-lighter">3 days ago - 23 min read</div>
												</div>
											</div>
										</div>
										<a href="#" class="shared">
											<i class="font-icon font-icon-share"></i>
										</a>
									</div>
									<div class="profile-post-content">
										<p class="profile-post-content-note">Scheduled a meeting whith <a href="#">Elen Adarna</a></p>
										<div class="tbl profile-post-card">
											<div class="tbl-row">
												<div class="tbl-cell tbl-cell-photo">
													<a href="#">
														<img src="img/100x100.jpg" alt="">
													</a>
												</div>
												<div class="tbl-cell">
													<p class="title"><a href="#">Telling Your Kife Story: Memoir Workshop Series</a></p>
													<p>Monday, July 06, 2015 – Thuesday, July 07, 2015</p>
													<p>SF Bay Theater</p>
													<p>San Francisco, California, USA</p>
												</div>
											</div>
										</div>
									</div>
									<div class="box-typical-footer profile-post-meta">
										<a href="#" class="meta-item">
											<i class="font-icon font-icon-heart"></i>
											45 Like
										</a>
										<a href="#" class="meta-item">
											<i class="font-icon font-icon-comment"></i>
											18 Comment
										</a>
									</div>
								</article>
							</div><!--.tab-pane-->