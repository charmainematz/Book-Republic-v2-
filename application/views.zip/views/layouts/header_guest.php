  <nav  style="background-color:#8D6658 ; " class="site-navbar navbar navbar-default navbar-fixed-top navbar-mega" role="navigation">
    <div class="navbar-header" style="background-color:#715146;" >
     
    
     
      <div class="navbar-brand navbar-brand-center">
       
        <span class="visible-md-*" style="color:#EEEEEE"></span>
      </div>
    </div>

    <div class="navbar-container container-fluid">
      <!-- Navbar Collapse -->
     <h4 ><a style="color:#F3F7F9"  href="<?=site_url('auth/home')?>" role="button">  <i class="icon icon-circle icon-1x wb-home " aria-hidden="true"></i> 
    <strong>  <?= $this->costumization_m->get(1)->hotel_name." ".$this->costumization_m->get(1)->sub_name;?> </strong>
    </a></h4>
      <!-- End Navbar Collapse -->

     
    </div>
  </nav>