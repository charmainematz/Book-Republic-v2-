<!DOCTYPE html>
<html class="no-js before-run" lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <meta name="description" content="bootstrap admin template">
  <meta name="author" content="">

<title><?= $this->costumization_m->get(1)->hotel_name." ".$this->costumization_m->get(1)->sub_name?></title>
<link rel="apple-touch-icon" href="<?=site_url('assets/images/apple-touch-icon.png')?>">
<link rel="shortcut icon" href="<?=site_url('assets/images/favicon.ico')?>">
  

  <!-- Stylesheets -->
  <link rel="stylesheet" href="<?=site_url('assets/css/bootstrap.min.css')?>">
  <link rel="stylesheet" href="<?=site_url('assets/css/bootstrap-extend.min.css')?>">
  <link rel="stylesheet" href="<?=site_url('assets/css/site.min.css')?>">
  

 
  <link rel="stylesheet" href="<?=site_url('assets/vendor/animsition/animsition.css')?>">
  <link rel="stylesheet" href="<?=site_url('assets/vendor/asscrollable/asScrollable.css')?>">
  <link rel="stylesheet" href="<?=site_url('assets/vendor/switchery/switchery.css')?>">
 
  <link rel="stylesheet" href="<?=site_url('assets/vendor/intro-js/introjs.css')?>">
  <link rel="stylesheet" href="<?=site_url('assets/vendor/slidepanel/slidePanel.css')?>">
  <link rel="stylesheet" href="<?=site_url('assets/vendor/flag-icon-css/flag-icon.css')?>">
 

  <!-- Plugin -->
  <link rel="stylesheet" href="<?=site_url('assets/vendor/slidepanel/slidePanel.css')?>">
  <link rel="stylesheet" href="<?=site_url('assets/vendor/bootstrap-markdown/bootstrap-markdown.css')?>">
  <link rel="stylesheet" href="<?=site_url('assets/vendor/select2/select2.css')?>">
  <link rel="stylesheet" href="<?=site_url('assets/css/apps/mailbox.css')?>">
  <link rel="stylesheet" href="<?=site_url('assets/vendor/webui-popover/webui-popover.css')?>">
  <link rel="stylesheet"  href="<?=site_url('assets/vendor/toolbar/toolbar.css')?>" >
  <link rel="stylesheet"  href="<?=site_url('assets/vendor/jquery-labelauty/jquery-labelauty.css')?>" >
  <link rel="stylesheet"  href="<?=site_url('assets/vendor/blueimp-file-upload/jquery.fileupload.css')?>" >
  <link rel="stylesheet"  href="<?=site_url('assets/vendor/formvalidation/formValidation.css')?>" >
  <link rel="stylesheet" href="<?=site_url('assets/css/apps/documents.css')?>">
 <link rel="stylesheet" href="<?=site_url('assets/vendor/bootstrap-select/bootstrap-select.css')?>">
 <link rel="stylesheet" href="<?=site_url('assets/vendor/asscrollable/asScrollable.css')?>">

   
 
  <link rel="stylesheet" href="<?=site_url('assets/vendor/dropzone/basic.css')?>">
  <link rel="stylesheet" href="<?=site_url('assets/vendor/dropzone/dropzone.css')?>">
  
  <!-- Plugin -->
  <link rel="stylesheet"  href="<?=site_url('assets/vendor/datatables-bootstrap/dataTables.bootstrap.css')?>">
 <link rel="stylesheet"  href="<?=site_url('assets/vendor/datatables-fixedheader/dataTables.fixedHeader.css')?>">
 <link rel="stylesheet"  href="<?=site_url('assets/vendor/datatables-responsive/dataTables.responsive.css')?>">
 <link rel="stylesheet"  href="<?=site_url('assets/vendor/magnific-popup/magnific-popup.css')?>">
<link rel="stylesheet"  href="<?=site_url('assets/vendor/bootstrap-datepicker/bootstrap-datepicker.css')?>">




  <link rel="stylesheet"  href="<?=site_url('assets/vendor/datatables-bootstrap/dataTables.bootstrap.css')?>">
  <link rel="stylesheet"  href="<?=site_url('assets/vendor/datatables-fixedheader/dataTables.fixedHeader.css')?>">
  <link rel="stylesheet"  href="<?=site_url('assets/vendor/datatables-responsive/dataTables.responsive.css')?>">
    <link rel="stylesheet"  href="<?=site_url('assets/css/pages/errors.css')?>">
 <link rel="stylesheet"  href="<?=site_url('assets/css/daterangepicker.css')?>">


 
  
  <link rel="stylesheet" href="<?=site_url('assets/fonts/font-awesome/font-awesome.css')?>">

 <link rel="stylesheet" href="<?=site_url('assets/css/../fonts/material-design/material-design.css')?>">  
  


  <link rel="stylesheet" href="<?=site_url('assets/fonts/web-icons/web-icons.min.css')?>">
   <link rel="stylesheet" href="<?=site_url('assets/fonts/brand-icons/brand-icons.min.css')?>">
 
  <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,300italic'>


  <!--[if lt IE 9]>
    <script src="../../assets/vendor/html5shiv/html5shiv.min.js"></script>
    <![endif]-->

  <!--[if lt IE 10]>
    <script src="../../assets/vendor/media-match/media.match.min.js"></script>
    <script src="../../assets/vendor/respond/respond.min.js"></script>
    <![endif]-->
 <style>
    .animation-delay-100 {
      -webkit-animation-delay: 100ms;
      animation-delay: 100ms;
    }
    
    .animation-duration-300 {
      -webkit-animation-duration: 300ms;
      animation-duration: 300ms;
    }
      .example {
      position: relative;
      padding: 10px;
      border: 1px solid #e4eaec;
    }
    
    .example .scrollable-horizontal .scrollable-content {
      width: 1400px;
    }
  </style>


  <?php if($page_title=='Dashboard'):?>

     <style>
    #exampleFlotCurve,
    #exampleFlotRealtime,
    #exampleFlotMix,
    #exampleFlotFullBg,
    #exampleFlotStackBar,
    #exampleFlotHorizontalBar,
    #exampleFlotPie,
    #exampleFlotVisitors {
      height: 300px;
    }
    
    #exampleFlotVisitorsOverview {
      height: 120px;
    }
    
    .legend td {
      padding: 3px;
    }
    
    @media (max-width: 586px) {
      .example-responsive {
        padding-bottom: 10px;
      }
    }
  </style>

     <style>
    @media (min-width: 768px) and (max-width: 992px) {
      .form-inline .control-label {
        display: block;
      }
      .form-inline .form-group {
        margin-bottom: 20px;
        vertical-align: baseline;
      }
    }
  </style>
   <style>
    .example .animation-example {
      display: inline-block;
      cursor: pointer;
    }
    
    .animation-delay-example button {
      -webkit-animation-name: fade-scale-02;
      -o-animation-name: fade-scale-02;
      animation-name: fade-scale-02;
      -webkit-animation-duration: .5s;
      -o-animation-duration: .5s;
      animation-duration: .5s;
      -webkit-animation-timing-function: ease-out;
      -o-animation-timing-function: ease-out;
      animation-timing-function: ease-out;
      -webkit-animation-fill-mode: both;
      -o-animation-fill-mode: both;
      animation-fill-mode: both;
    }
    
    .touch .animation-delay-example:not(.hover) button,
    .animation-delay-example:not(:hover) button {
      -webkit-animation-name: none;
      -o-animation-name: none;
      animation-name: none;
    }
  </style>
  <style>
    .bootstrap-select {
      width: 100% !important;
    }
    
    .datepair-wrap {
      position: relative;
      overflow: hidden;
    }
    
    .input-daterange-wrap {
      float: left;
    }
    
    .input-daterange-to {
      float: left;
      width: 40px;
      height: 40px;
      line-height: 40px;
      text-align: center;
    }
    
    @media (max-width: 1360px) {
      .input-daterange-wrap,
      .input-daterange-to {
        display: block;
        float: none;
      }
    }
  </style>
   <style>
    .lightbox-block {
      max-width: 600px;
      padding: 15px 20px;
      margin: 40px auto;
      overflow: auto;
      background: #fff;
      border-radius: 3px;
    }
  </style>
<?php endif;?>
  <!-- Scripts -->
  <script src="<?=site_url('assets/vendor/modernizr/modernizr.js');?>"></script>
  <script src="<?=site_url('assets/vendor/breakpoints/breakpoints.js');?>"></script>
  <script>
    Breakpoints();
  </script>
</head>
