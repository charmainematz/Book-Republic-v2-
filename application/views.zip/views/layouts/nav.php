 <div class="site-menubar">
    <div class="site-menubar-body">
      <div>
        <div>
          <ul class="site-menu">
            <li class="site-menu-category">General</li>
            <li class="site-menu-item">
              <a href="<?=site_url('dashboard')?>" data-slug="dashboard">
                <i class="site-menu-icon wb-dashboard" aria-hidden="true"></i>
                <span class="site-menu-title">Dashboard</span>
               
              </a>
           
            </li>
         
            
            <?php 

         $notif = $this->reservation_m->getNotification();

         ?>
       
              
            <li class="site-menu-category">Bookings</li>
            <li class="site-menu-item ">
              <a  href="<?=site_url('booking')?>" data-slug="app">
                <i class="site-menu-icon incon fa-hotel" aria-hidden="true"></i>
                <span class="site-menu-title">All</span>
                <div class="site-menu-badge">
                     <?php if(count($notif)>0){?>
              <span class="badge badge-success "><?=count($notif)?></span>
              <?php }?>
            </div>
              </a>
             
            </li>
            <li class="site-menu-item ">
              <a href="<?=site_url('booking/current')?>" data-slug="advanced">
                <i class="site-menu-icon icon md-notifications-active" aria-hidden="true"></i>
                <span class="site-menu-title">Current Check-ins</span>
               
              </a>
              
            </li>
            <li class="site-menu-item ">
              <a href="<?=site_url('booking/future')?>" data-slug="structure">
                <i class="site-menu-icon icon md-notifications-none" aria-hidden="true"></i>
                <span class="site-menu-title">Future Check-ins</span>
               
              </a>
                
            </li>
         
            <li class="site-menu-category">Apps</li>
            
            
            <li class="site-menu-item">
              <a href="<?=site_url('billing')?>"  data-slug="app">
                <i class="site-menu-icon wb-grid-4" aria-hidden="true"></i>
                <span class="site-menu-title">Billing Management</span>
                
              </a>
             
            </li>
            <li class="site-menu-item">
              <a href="<?=site_url('mail')?>" role="button" >
                <i class="site-menu-icon wb-grid-4" aria-hidden="true"></i>
                <span class="site-menu-title">Mailbox</span>
                
              </a>
             
            </li>

               <li class="site-menu-item">
              <a h href="<?=site_url('settings')?>" role="button">
                <i class="site-menu-icon wb-grid-4" aria-hidden="true"></i>
                <span class="site-menu-title">Masterlist</span>
              
              </a>
             
            </li>
              <li class="site-menu-item">
              <a href="<?=site_url('dashboard/load_analytics')?>" role="button" >
                <i class="site-menu-icon wb-grid-4" aria-hidden="true"></i>
                <span class="site-menu-title">Reports</span>
                
              </a>
             
            </li>
            <li class="site-menu-item ">
              <a href="<?=site_url('room/manager')?>" data-slug="app">
                <i class="site-menu-icon wb-grid-4" aria-hidden="true"></i>
                <span class="site-menu-title">Room Manager</span>
              
              </a>
             
            </li>
            
             <li class="site-menu-item">
              <a  href="<?=site_url('costumization')?>" role="button">
                <i class="site-menu-icon wb-grid-4" aria-hidden="true"></i>
                <span class="site-menu-title">Site Customizer</span>
              
              </a>
             
            </li>

            <li class="site-menu-category">Account</li>
              <li class="site-menu-item">
              <a  href="<?=site_url('user')?>" role="button">
                <i class="site-menu-icon wb-grid-4" aria-hidden="true"></i>
                <span class="site-menu-title">Admin Account</span>
              
              </a>
             
            </li>
             
          </ul>

        
        </div>
      </div>
    </div>

   
  </div>