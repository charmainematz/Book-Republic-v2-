<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">

            <div class="menu_section">
              <h3 text-align="center">Client</h3>
            
              <ul class="nav side-menu">
                  <li><a href="<?=site_url('dashboard')?>"><i class="fa fa-dashboard"></i> Dashboard <span></span></a>
                  <li><a href="<?=site_url('event/create')?>"><i class="fa fa-edit" ></i> Create an Event</a>
              
                </li>
                <li>
                  
                </li>
                <li><a href="<?=site_url('event/mybookings')?>"> <i class="fa fa-bookmark"></i> My Bookings </a>
                  
                
               
                
              
              </ul>
            </div>
          

          </div>

