
	<?php $this->load->view('layouts/page-header'); ?>	
 	<body>
  		
		<?php
		$this->load->view('layouts/header');
		$this->load->view('layouts/nav'); ?>

          <!-- Example With Description -->
		 <!-- Page -->
 
  	<div class="page ">
  		<?php if($page_title!='Dashboard'):?>
	    <div class="page-header">
	     
	       
	          	 <h1 class="page-title"><?=$page_title?></h1>
	          	 <p class="page-description">
                  <?=$page_desc?>
                </p>
			      <div class="page-header-actions">
			        <ol class="breadcrumb">
			          <li><a href="<?=site_url()?>">Home</a></li>
			          <li><?=$page_title?></li>
			       
			        </ol>
			      </div>
			 
	    </div>

    <div class="page-content container-fluid">
    		  <?php endif?>
	     <?php $this->load->view($subview); ?>
	    
 	 <!-- End Page -->
 	</div>
 	</div>
	        		
	<?php $this->load->view('layouts/page-footer'); ?>
	<!-- /page content already at footer --> 

	  
	