 <div style="background-color:  #E4EAEC; color:#8D6658; padding:30px;"  class="site-menubar">
 	  <!-- Panel Checkbox & Radio -->
      <div class="row">      
         
          <div class="col-lg-12">
              <!-- Example Checkboxes -->     

              <?php if($page_title=="Forgot Password"||$page_title=="Password Reset"){

              }else{?>
               <?php if($m!='View Booking'):?>
                
                    <h4 style="color:#8D6658; " class="example-title"><strong>Filter by Amenities</strong> </h4>
                    <div style="overflow-y: scroll;height: 300px">
             
                
                      <?php 
                      $amenities = $this->inclusion_m->get();
                      foreach($amenities as $amenity): ?>

                

                          <form >              
                              <input type="checkbox" name="amenities" id="inputChecked" value="<?= $amenity->inclusion_name?>"/>
                              <label for="inputChecked"><?= $amenity->inclusion_name?></label>
                        </form>                 
                      <?php endforeach;?>
                    </div>
         
                     <br>
                     <div style="overflow-y:scroll;height: 300px">
                      <h4 style="color:#8D6658; " class="example-title"><strong>Filter By Room Type</strong> </h4>
                      
                        <?php 
                        $room_types = $this->room_type_m->get();
                        foreach($room_types as $rt):?>

                       
                          <form action="<?=site_url('room/showAvailableRooms')?>" method="post">
                              <input type="checkbox" class="roomtype" name="room_types" id="inputChecked" value="<?= $rt->room_type_id?>" />
                              <label for="inputChecked"><?= $rt->room_type_name?></label>
                          </form>
                      
                      <?php endforeach;?>
                    </div>
              <?php endif;?>
    <?php }?>
          </div>
         
      </div>
</div>          <!-- End Example Checkboxes -->
         