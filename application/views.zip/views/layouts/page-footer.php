<?php
$hotel= $this->costumization_m->get(1);

?>

<!-- Footer -->
  <footer class="site-footer">
   
    <span class="site-footer-left">
         <span><?="Powered by <strong>".$app_title?></strong></span>
         
    </span>
    <div class="site-footer-right">
         <p><?="© ".date('Y')." ".$hotel->hotel_name." ".$hotel->sub_name?></p>
         
    </div>
  </footer>

  <!-- Core  -->
  <script src="<?=site_url('assets/vendor/jquery/jquery.js');?>"></script>
  <script src="<?=site_url('assets/vendor/bootstrap/bootstrap.js');?>"></script>
  <script src="<?=site_url('assets/vendor/animsition/jquery.animsition.js');?>"></script>
  <script src="<?=site_url('assets/vendor/asscroll/jquery-asScroll.js');?>"></script>
  <script src="<?=site_url('assets/vendor/mousewheel/jquery.mousewheel.js');?>"></script>
  <script src="<?=site_url('assets/vendor/asscrollable/jquery.asScrollable.all.js');?>"></script>
  <script src="<?=site_url('assets/vendor/ashoverscroll/jquery-asHoverScroll.js');?>"></script>
 
  <!-- Plugins -->
  <script src="<?=site_url('assets/vendor/switchery/switchery.min.js');?>"></script>
  <script src="<?=site_url('assets/vendor/intro-js/intro.js');?>"></script>
   <script src="<?=site_url('assets/vendor/screenfull/screenfull.js');?>"></script>
 <script src="<?=site_url('assets/vendor/slidepanel/jquery-slidePanel.js');?>"></script>
   <script src="<?=site_url('assets/vendor/webui-popover/jquery.webui-popover.min.js');?>"></script>
 <script src="<?=site_url('assets/vendor/toolbar/jquery.toolbar.min.js');?>"></script>
  <script src="<?=site_url('assets/vendor/datatables/jquery.dataTables.min.js');?>" ></script>

  <script src="<?=site_url('assets/vendor/datatables-bootstrap/dataTables.bootstrap.js');?>" ></script>
  <script src="<?=site_url('assets/vendor/datatables-responsive/dataTables.responsive.js');?>" ></script>
  <script  src="<?=site_url('assets/vendor/datatables-tabletools/dataTables.tableTools.js')?>"></script>
  <script  src="<?=site_url('assets/vendor/jquery-labelauty/jquery-labelauty.js')?>"></script>

  
  <script  src="<?=site_url('assets/vendor/jquery-ui/jquery-ui.js')?>"></script>
  <script  src="<?=site_url('assets/vendor/blueimp-tmpl/tmpl.js')?>"></script>
  <script  src="<?=site_url('assets/vendor/blueimp-canvas-to-blob/canvas-to-blob.js')?>"></script>
  <script  src="<?=site_url('assets/vendor/blueimp-load-image/load-image.all.min.js')?>"></script>
  <script  src="<?=site_url('assets/vendor/blueimp-file-upload/jquery.fileupload.js')?>"></script>

  <script  src="<?=site_url('assets/vendor/blueimp-file-upload/jquery.fileupload-process.js')?>"></script>

  <script  src="<?=site_url('assets/vendor/blueimp-file-upload/jquery.fileupload-image.js')?>"></script>
  <script  src="<?=site_url('assets/vendor/blueimp-file-upload/jquery.fileupload-audio.js')?>"></script>
  <script  src="<?=site_url('assets/vendor/blueimp-file-upload/jquery.fileupload-video.js')?>"></script>
  <script  src="<?=site_url('assets/vendor/blueimp-file-upload/jquery.fileupload-validate.js')?>"></script>
  <script  src="<?=site_url('assets/vendor/blueimp-file-upload/jquery.fileupload-ui.js')?>"></script>
  <script  src="<?=site_url('assets/js/components/bootstrap-datepicker.js')?>"></script>
  <script  src="<?=site_url('assets/vendor/datepicker/moment.js')?>"></script>
  <script  src="<?=site_url('assets/vendor/datepicker/daterangepicker.js')?>"></script>
 

  <script  src="<?=site_url('assets/vendor/formvalidation/formValidation.min.js')?>"></script>
  <script  src="<?=site_url('assets/vendor/formvalidation/framework/bootstrap.min.js')?>"></script>

  <script  src="<?=site_url('assets/vendor/flot/jquery.flot.js')?>"></script>  
  <script  src="<?=site_url('assets/vendor/flot/jquery.flot.resize.js')?>"></script> 
  <script  src="<?=site_url('assets/vendor/flot/jquery.flot.time.js')?>"></script>  
  <script  src="<?=site_url('assets/vendor/flot/jquery.flot.stack.js')?>"></script>   
  <script  src="<?=site_url('assets/vendor/flot/jquery.flot.pie.js')?>"></script>   
  <script  src="<?=site_url('assets/vendor/flot/jquery.flot.selection.js')?>"></script>   

  <script  src="<?=site_url('assets/vendor/d3/d3.min.js')?>"></script>   
  <script  src="<?=site_url('assets/vendor/c3/c3.min.js')?>"></script>   
    <script  src="<?=site_url('assets/js/html2canvas.js')?>"></script>   
  <script  src="<?=site_url('assets/js/jspdf-min.js')?>"></script>   



  <!-- Scripts -->
 
  <script src="<?=site_url('assets/js/core.js');?>"></script>
  <script src="<?=site_url('assets/js/site.js');?>"></script>

<script src="<?=site_url('assets/js/sections/menu.js');?>"></script>
<script src="<?=site_url('assets/js/sections/menubar.js');?>"></script>
<script src="<?=site_url('assets/js/sections/sidebar.js');?>"></script>
      
<script src="<?=site_url('assets/js/configs/config-colors.js');?>"></script>
<script src="<?=site_url('assets/js/configs/config-tour.js');?>"></script>
<script src="<?=site_url('assets/js/components/asscrollable.js');?>"></script>
<script src="<?=site_url('assets/js/components/animsition.js');?>"></script>
<script src="<?=site_url('assets/js/components/slidepanel.js');?>"></script>
<script src="<?=site_url('assets/js/components/switchery.js');?>"></script>


<script src="<?=site_url('assets/js/apps/app.js');?>"></script>
<script src="<?=site_url('assets/js/apps/mailbox.js');?>"></script>
<script src="<?=site_url('assets/js/components/select2.js');?>"></script>
<script src="<?=site_url('assets/js/components/webui-popover.js');?>"></script>
<script src="<?=site_url('assets/js/components/toolbar.js');?>"></script>
<script src="<?=site_url('assets/js/apps/documents.js');?>"></script>

  <script  src="<?=site_url('assets/js/components/asscrollable.js')?>"></script>   


<script src="<?=site_url('assets/js/components/datatables.js');?>"></script>
 <?php if($page_title=='Room Manager'||$page_desc=='Room'):     $this->load->view('room/scripts');     endif ?>

<script>
    (function(document, window, $) {
      'use strict';

      var Site = window.Site;
      var AppMailbox = window.AppMailbox;

     

     $(document).ready(function() {
        Site.run();
        AppMailbox.run();

         if ($('.list-group[data-plugin="nav-tabs"]').length) {
          $('a[data-toggle="tab"]').on('shown.bs.tab', function(e) {
            $(e.target).addClass('active').siblings().removeClass(
              'active');
          });
        }


 

   });
       
    
    })(document, window, jQuery);
  </script>
  <?php if($page_title=='Billing Management'): $this->load->view('billing_management/scripts'); endif ?>
  <?php if($page_title=='Dashboard'): $this->load->view('dashboard/scripts'); endif ?>
    <?php if($page_title=='Analytics'): $this->load->view('dashboard/analytics_scripts'); endif ?>

  <?php if($page_title=='Room Type'): $this->load->view('room_type/scripts'); endif ?>
  <?php if($page_title=='Inclusion'): $this->load->view('inclusion/scripts'); endif ?>
  <?php if($page_title=='Facility'):  $this->load->view('facility/scripts');  endif ?>
  <?php if($page_title=='Addon'):     $this->load->view('addon/scripts');     endif ?>
   <?php if($page_title=='Status'):     $this->load->view('status/scripts');     endif ?>

   
</body>

</html>