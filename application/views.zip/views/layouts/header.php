  <nav class="site-navbar navbar navbar-default navbar-fixed-top navbar-mega" role="navigation">

    <div class="navbar-header" >
      <button type="button" class="navbar-toggle hamburger hamburger-close navbar-toggle-left hided"
      data-toggle="menubar">
        <span class="sr-only">Toggle navigation</span>
        <span class="hamburger-bar"></span>
      </button>
      <button type="button" class="navbar-toggle collapsed" data-target="#site-navbar-collapse"
      data-toggle="collapse">
        <i class="icon wb-more-horizontal" aria-hidden="true"></i>
      </button>
      
      <div class="navbar-brand navbar-brand-center site-gridmenu-toggle" data-toggle="gridmenu">
        <img class="navbar-brand-logo" src="<?=site_url('assets/images/logo.png')?>" title="Remark">
        <span class="visible-md-*">iHotel Manager</span>
      </div>
    </div>
        <div class="navbar-container container-fluid">
      <!-- Navbar Collapse -->
      <div class="collapse navbar-collapse navbar-collapse-toolbar" id="site-navbar-collapse">
        <!-- Navbar Toolbar -->
         <!-- Navbar Toolbar Right -->
        <ul class="nav navbar-toolbar navbar-right navbar-toolbar-right">
         
          <!-- Navbar Toolbar Right -->
        <ul class="nav navbar-toolbar navbar-right navbar-toolbar-right">
            <?php 

         $notif1 = $this->inquiry_m->getNotification();
        

         ?>
           <li class="dropdown">
            <a data-toggle="dropdown" href="javascript:void(0)" title="Messages" aria-expanded="false"
            data-animation="slide-bottom" role="button">
                 
                    <i class="icon wb-envelope" aria-hidden="true"></i>
                      <?php if(count($notif1)>0){?>
              <span class="badge badge-danger up"><?=count($notif1)?></span>
              <?php }?>
            </a>
            <ul class="dropdown-menu dropdown-menu-right dropdown-menu-media" role="menu">
              <li class="dropdown-menu-header" role="presentation">
                <h5>MESSAGES</h5>
               		
              </li>
      <?php foreach($notif1 as $notif){?>
              <li class="list-group" role="presentation">
                <div data-role="container">
                  <div data-role="content">
                    <a class="list-group-item" href="<?=site_url('mail/clearNotif/'.$notif->inquiry_id)?>" role="menuitem">
                      <div class="media">
                        <div class="media-body">
                          <h6 class="media-heading"><?=$notif->name?></h6>
                          <div class="media-meta">
                            <time datetime="2015-06-17T20:22:05+08:00"><?=$this->inquiry_m->time_elapsed_string($notif->date_created, true);?></time>
                          </div>
                          <div class="media-detail"><?=$notif->message?></div>
                        </div>
                      </div>
                    </a>
              </li>
               <?php }?>
            </ul>
          </li>
         <?php 

         $notif = $this->reservation_m->getNotification();

         ?>
       
          <li class="dropdown">
            <a data-toggle="dropdown" title="Notifications" aria-expanded="false"
            data-animation="slide-bottom" role="button">
              <i class="icon wb-bell" aria-hidden="true"></i>

              <?php if(count($notif)>0){?>
              <span class="badge badge-danger up"><?=count($notif)?></span>
              <?php }?>
            </a>
            <ul class="dropdown-menu dropdown-menu-right dropdown-menu-media" role="menu">
              <li class="dropdown-menu-header" role="presentation">
                <h5>NOTIFICATIONS</h5>
               
              </li>

              <?php foreach($notif as $not){?>
              <li class="list-group" role="presentation">
                <div data-role="container">
                  <div data-role="content">
                    <a class="list-group-item"  href="<?=site_url('booking/view/'.$not->reservation_id)?>" role="menuitem">
                      <div class="media">
                        <div class="media-left padding-right-10">
                          <i class="icon wb-order bg-red-600 white icon-circle" aria-hidden="true"></i>
                        </div>
                        <div class="media-body">
                          <h6 class="media-heading">A new reservation has been booked</h6>
                          <time class="media-meta" datetime="2015-06-12T20:50:48+08:00"><?=$this->inquiry_m->time_elapsed_string($not->date_created, true);?></time>
                        </div>
                      </div>
                    </a>
                    
                  </div>
                </div>
              </li>
            <?php }?>
            </ul>
          </li>
          
       
          <li class="dropdown">

          
            <a class="navbar-avatar dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false"
            data-animation="slide-bottom" role="button">

              <span class="avatar avatar-online">
                <img src="<?=site_url('images/profile.png')?>">
                <i></i>
              </span>
            </a>
            <ul class="dropdown-menu" role="menu">
              <li role="presentation">    
               <a  href="<?=site_url('auth/home')?>" role="menuitem"> <i class="icon wb-home" aria-hidden="true"></i> Homepage   </a></li>
              <li role="presentation">
                <a href="<?=site_url('costumization')?>"  role="menuitem"><i class="icon wb-settings" aria-hidden="true"></i> Settings</a>
              </li>
            
              <li role="presentation">
                <a href="<?=site_url('auth/logout')?>" role="menuitem"><i class="icon wb-power" aria-hidden="true"></i> Logout</a>
              </li>
            </ul>
          </li>
          <li>
          </li>
        </ul>

       </div>
       </div> <!-- End Navbar Toolbar Right -->

  </nav>